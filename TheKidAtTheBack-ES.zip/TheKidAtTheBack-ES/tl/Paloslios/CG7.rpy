


    ####
    ##                                      ##
    ##  F95Zone Paloslios Renpy Translator  ##
    ##     https://ko-fi.com/paloslios      ##
    ##                                      ##
    ####



translate Paloslios strings:

    # C:/Users/NICOLLE/Desktop/novelas visuales/game/day1_2.rpy:297
    old "Yes"
    new "Sí"

    # C:/Users/NICOLLE/Desktop/novelas visuales/game/day1_2.rpy:297
    old "No"
    new "No"

    # C:/Users/NICOLLE/Desktop/novelas visuales/game/day1_2.rpy:309
    old "Vagina"
    new "Vagina"

    # C:/Users/NICOLLE/Desktop/novelas visuales/game/day1_2.rpy:309
    old "Penis"
    new "Pene"

    # C:/Users/NICOLLE/Desktop/novelas visuales/game/day1_2.rpy:504
    old "she/her/hers"
    new "ella"

    # C:/Users/NICOLLE/Desktop/novelas visuales/game/day1_2.rpy:504
    old "he/him/his"
    new "él"

    # C:/Users/NICOLLE/Desktop/novelas visuales/game/day1_2.rpy:504
    old "they/them/theirs"
    new "elle"

    # C:/Users/NICOLLE/Desktop/novelas visuales/game/day1_2.rpy:512
    old "Neutral"
    new "Neutral"

    # C:/Users/NICOLLE/Desktop/novelas visuales/game/day1_2.rpy:512
    old "Feminine"
    new "Femenino"

    # C:/Users/NICOLLE/Desktop/novelas visuales/game/day1_2.rpy:512
    old "Masculine"
    new "Masculino"

    # C:/Users/NICOLLE/Desktop/novelas visuales/game/day1_2.rpy:526
    old "This doesn't seem right... Maybe my eyes are itching..."
    new "Esto no parece correcto... Tal vez me pican los ojos..."

    # C:/Users/NICOLLE/Desktop/novelas visuales/game/day1_2.rpy:711
    old "Go with them."
    new "Ve con ellos."

    # C:/Users/NICOLLE/Desktop/novelas visuales/game/day1_2.rpy:711
    old "To go to the library."
    new "Ir a la biblioteca."

    # C:/Users/NICOLLE/Desktop/novelas visuales/game/day1_2.rpy:711
    old "Go somewhere else"
    new "Ir a otro lugar"

    # C:/Users/NICOLLE/Desktop/novelas visuales/game/day1_2.rpy:886
    old "I have my own lunch"
    new "Tengo mi propio almuerzo"

    # C:/Users/NICOLLE/Desktop/novelas visuales/game/day1_2.rpy:886
    old "Buy your lunch"
    new "Compra tu almuerzo"

    # C:/Users/NICOLLE/Desktop/novelas visuales/game/day1_2.rpy:1022
    old "I don't know..."
    new "No sé..."

    # C:/Users/NICOLLE/Desktop/novelas visuales/game/day1_2.rpy:1022
    old "Say nothing"
    new "No decir nada"

    # C:/Users/NICOLLE/Desktop/novelas visuales/game/day1_2.rpy:1284
    old "Find somewhere else to sit."
    new "Busca otro lugar para sentarte."

    # C:/Users/NICOLLE/Desktop/novelas visuales/game/day1_2.rpy:1284
    old "Ask them to move away from your seat"
    new "Pídele que se aleje de tu asiento"

    # C:/Users/NICOLLE/Desktop/novelas visuales/game/day1_2.rpy:1284
    old "Just take the seat beside him"
    new "Simplemente toma el asiento a su lado"

    # C:/Users/NICOLLE/Desktop/novelas visuales/game/day1_2.rpy:1377
    old "Quickly leave the scene"
    new "Sal de la escena rápidamente"

    # C:/Users/NICOLLE/Desktop/novelas visuales/game/day1_2.rpy:1377
    old "Stop them"
    new "Deténlos"

    # C:/Users/NICOLLE/Desktop/novelas visuales/game/day1_2.rpy:1577
    old "Coffee"
    new "Café"

    # C:/Users/NICOLLE/Desktop/novelas visuales/game/day1_2.rpy:1577
    old "Force him to give up his seat"
    new "Haz que ceda su asiento"

    # C:/Users/NICOLLE/Desktop/novelas visuales/game/day1_2.rpy:1588
    old "Mocha"
    new "Moca"

    # C:/Users/NICOLLE/Desktop/novelas visuales/game/day1_2.rpy:1588
    old "Latte"
    new "Latte"

    # C:/Users/NICOLLE/Desktop/novelas visuales/game/day1_2.rpy:1588
    old "Black"
    new "Negro"

    # C:/Users/NICOLLE/Desktop/novelas visuales/game/day1_2.rpy:2197
    old "Stay silent"
    new "Mantente en silencio"

    # C:/Users/NICOLLE/Desktop/novelas visuales/game/day1_2.rpy:2197
    old "Surrender"
    new "Ríndete"

    # C:/Users/NICOLLE/Desktop/novelas visuales/game/day1_2.rpy:2789
    old "Sol means sun or brightness right?"
    new "¿Sol significa sol o luminosidad, verdad?"

    # C:/Users/NICOLLE/Desktop/novelas visuales/game/day1_2.rpy:2789
    old "Your name contradicts with your whole glam not gonna lie"
    new "Tu nombre contradice todo tu glamour, no voy a mentir"

    # C:/Users/NICOLLE/Desktop/novelas visuales/game/day1_2.rpy:2966
    old "Am not that good at art"
    new "No soy tan buen@ en arte"

    # C:/Users/NICOLLE/Desktop/novelas visuales/game/day1_2.rpy:2966
    old "Pretty great at art."
    new "Bastante buen@ en arte."

    # C:/Users/NICOLLE/Desktop/novelas visuales/game/day1_2.rpy:3926
    old "Take his hand"
    new "Toma su mano"

    # C:/Users/NICOLLE/Desktop/novelas visuales/game/day1_2.rpy:3926
    old "Take his arm"
    new "Toma su brazo"

    # C:/Users/NICOLLE/Desktop/novelas visuales/game/day1_2.rpy:4046
    old "I do"
    new "Sí"

    # C:/Users/NICOLLE/Desktop/novelas visuales/game/day1_2.rpy:4046
    old "I don't"
    new "No"

    # C:/Users/NICOLLE/Desktop/novelas visuales/game/day1_2.rpy:4229
    old "Hug him"
    new "Abrázalo"

    # C:/Users/NICOLLE/Desktop/novelas visuales/game/day1_2.rpy:4229
    old "Kiss him"
    new "Bésalo"

    # C:/Users/NICOLLE/Desktop/novelas visuales/game/day1_2.rpy:5110
    old "Join Sol"
    new "Únete a Sol"

    # C:/Users/NICOLLE/Desktop/novelas visuales/game/day1_2.rpy:5110
    old "Call Sol over"
    new "Llama a Sol"

    # C:/Users/NICOLLE/Desktop/novelas visuales/game/day1_2.rpy:5110
    old "Stay with the group"
    new "Quédate con el grupo"

    # C:/Users/NICOLLE/Desktop/novelas visuales/game/day1_2.rpy:5231
    old "Join Sol and Hyugo."
    new "Únete a Sol y Hyugo."

    # C:/Users/NICOLLE/Desktop/novelas visuales/game/day1_2.rpy:5552
    old "Sit beside Sol"
    new "Siéntate al lado de Sol"

    # C:/Users/NICOLLE/Desktop/novelas visuales/game/day1_2.rpy:5552
    old "Sit in between them"
    new "Siéntate entre ellos"

    # C:/Users/NICOLLE/Desktop/novelas visuales/game/day1_2.rpy:5552
    old "Sit beside Hyugo"
    new "Siéntate al lado de Hyugo"

    # C:/Users/NICOLLE/Desktop/novelas visuales/game/day1_2.rpy:5607
    old "Yes I have"
    new "Sí, lo he hecho"

    # C:/Users/NICOLLE/Desktop/novelas visuales/game/day1_2.rpy:5607
    old "No I haven't actually"
    new "No, en realidad no"

    # C:/Users/NICOLLE/Desktop/novelas visuales/game/day1_2.rpy:5677
    old "Take a bite from the bento box."
    new "Toma un bocado del bento."

    # C:/Users/NICOLLE/Desktop/novelas visuales/game/day1_2.rpy:5677
    old "Tease him"
    new "Burlarte de él"

    # C:/Users/NICOLLE/Desktop/novelas visuales/game/day1_2.rpy:5728
    old "Making lunch for Hyugo..."
    new "Preparando almuerzo para Hyugo..."

    # C:/Users/NICOLLE/Desktop/novelas visuales/game/day1_2.rpy:5728
    old "You'd make a great househusband!"
    new "¡Serías un gran esposo!"

    # C:/Users/NICOLLE/Desktop/novelas visuales/game/day1_2.rpy:5824
    old "No!"
    new "¡No!"

    # C:/Users/NICOLLE/Desktop/novelas visuales/game/day1_2.rpy:5824
    old "...Maybe..."
    new "...Tal vez..."

    # C:/Users/NICOLLE/Desktop/novelas visuales/game/day1_2.rpy:5983
    old "High Class?"
    new "¿Alta clase?"

    # C:/Users/NICOLLE/Desktop/novelas visuales/game/day1_2.rpy:5983
    old "About the Hierarchy."
    new "Sobre la jerarquía."

    # C:/Users/NICOLLE/Desktop/novelas visuales/game/day1_2.rpy:5983
    old "I have nothing else to ask."
    new "No tengo nada más que preguntar."

    # C:/Users/NICOLLE/Desktop/novelas visuales/game/day1_2.rpy:6201
    old "A little bit"
    new "Un poquito"

    # C:/Users/NICOLLE/Desktop/novelas visuales/game/day1_2.rpy:6201
    old "Not at all"
    new "Para nada"

    # C:/Users/NICOLLE/Desktop/novelas visuales/game/day1_2.rpy:6284
    old "Fuck it, we skip"
    new "Al diablo, lo saltamos"

    # C:/Users/NICOLLE/Desktop/novelas visuales/game/day1_2.rpy:6284
    old "I couldn't afford to skip this one..."
    new "No podía permitirme saltarme este..."

    # C:/Users/NICOLLE/Desktop/novelas visuales/game/day1_2.rpy:6321
    old "Keep Walking."
    new "Sigue caminando."

    # C:/Users/NICOLLE/Desktop/novelas visuales/game/day1_2.rpy:6495
    old "Speak to Geo"
    new "Habla con Geo"

    # C:/Users/NICOLLE/Desktop/novelas visuales/game/day1_2.rpy:6495
    old "Speak to Deryl"
    new "Habla con Deryl"

    # C:/Users/NICOLLE/Desktop/novelas visuales/game/day1_2.rpy:6495
    old "Speak to Brittney"
    new "Habla con Brittney"

    # C:/Users/NICOLLE/Desktop/novelas visuales/game/day1_2.rpy:6495
    old "Speak to Jess"
    new "Habla con Jess"

    # C:/Users/NICOLLE/Desktop/novelas visuales/game/day1_2.rpy:6495
    old "Look for Crowe"
    new "Busca a Crowe"

    # C:/Users/NICOLLE/Desktop/novelas visuales/game/day1_2.rpy:6518
    old "N-nothing!"
    new "¡N-nada!"

    # C:/Users/NICOLLE/Desktop/novelas visuales/game/day1_2.rpy:6518
    old "I have questions..."
    new "Tengo preguntas..."

    # C:/Users/NICOLLE/Desktop/novelas visuales/game/day1_2.rpy:6605
    old "About Geo."
    new "Sobre Geo."

    # C:/Users/NICOLLE/Desktop/novelas visuales/game/day1_2.rpy:6605
    old "About Deryl"
    new "Sobre Deryl"

    # C:/Users/NICOLLE/Desktop/novelas visuales/game/day1_2.rpy:6605
    old "About Jess"
    new "Sobre Jess"

    # C:/Users/NICOLLE/Desktop/novelas visuales/game/day1_2.rpy:6605
    old "About Brittney."
    new "Sobre Brittney."

    # C:/Users/NICOLLE/Desktop/novelas visuales/game/day1_2.rpy:6605
    old "About Crowe"
    new "Sobre Crowe"

    # C:/Users/NICOLLE/Desktop/novelas visuales/game/day1_2.rpy:6605
    old "I have nothing else to ask"
    new "No tengo nada más que preguntar"

    # C:/Users/NICOLLE/Desktop/novelas visuales/game/day1_2.rpy:6794
    old "They were wonderful Brittney"
    new "Fueron maravillosos, Brittney"

    # C:/Users/NICOLLE/Desktop/novelas visuales/game/day1_2.rpy:6794
    old "I couldn't finish it, sorry."
    new "No pude terminarlo, lo siento."

    # C:/Users/NICOLLE/Desktop/novelas visuales/game/day1_2.rpy:6807
    old "Have you seen Crowe?"
    new "¿Has visto a Crowe?"

    # C:/Users/NICOLLE/Desktop/novelas visuales/game/day1_2.rpy:6807
    old "Thoughts on Deryl"
    new "Opiniones sobre Deryl"

    # C:/Users/NICOLLE/Desktop/novelas visuales/game/day1_2.rpy:6807
    old "Thoughts on Geo."
    new "Opiniones sobre Geo."

    # C:/Users/NICOLLE/Desktop/novelas visuales/game/day1_2.rpy:6807
    old "Thoughts on Jess"
    new "Opiniones sobre Jess"

    # C:/Users/NICOLLE/Desktop/novelas visuales/game/day1_2.rpy:6807
    old "Nothing else."
    new "Nada más."

    # C:/Users/NICOLLE/Desktop/novelas visuales/game/day1_2.rpy:6932
    old "Thoughts on Geo"
    new "Opiniones sobre Geo"

    # C:/Users/NICOLLE/Desktop/novelas visuales/game/day1_2.rpy:6932
    old "Thoughts on Deryl."
    new "Opiniones sobre Deryl."

    # C:/Users/NICOLLE/Desktop/novelas visuales/game/day1_2.rpy:6932
    old "Thoughts on Brittney."
    new "Opiniones sobre Brittney."

    # C:/Users/NICOLLE/Desktop/novelas visuales/game/day1_2.rpy:6932
    old "No more questions."
    new "No más preguntas."

    # C:/Users/NICOLLE/Desktop/novelas visuales/game/day1_2.rpy:7114
    old "The lower class..."
    new "La clase baja..."

    # C:/Users/NICOLLE/Desktop/novelas visuales/game/day1_2.rpy:7114
    old "The Hierarchy?"
    new "¿La jerarquía?"

    # C:/Users/NICOLLE/Desktop/novelas visuales/game/day1_2.rpy:7114
    old "Both of those sound so..."
    new "Ambos suenan tan..."

    # C:/Users/NICOLLE/Desktop/novelas visuales/game/day1_2.rpy:7233
    old "He's cute"
    new "Es lindo"

    # C:/Users/NICOLLE/Desktop/novelas visuales/game/day1_2.rpy:7233
    old "Nothing more but a classmate"
    new "Nada más que un compañero de clase"

    # C:/Users/NICOLLE/Desktop/novelas visuales/game/day1_2.rpy:7274
    old "Lean in"
    new "Acércate"

    # C:/Users/NICOLLE/Desktop/novelas visuales/game/day1_2.rpy:7274
    old "Stay put"
    new "Quédate quieto"

    # C:/Users/NICOLLE/Desktop/novelas visuales/game/day1_2.rpy:7346
    old "Skip class."
    new "Saltarse la clase."

    # C:/Users/NICOLLE/Desktop/novelas visuales/game/day1_2.rpy:7346
    old "I can't skip class"
    new "No puedo saltarme la clase"

    # C:/Users/NICOLLE/Desktop/novelas visuales/game/day1_2.rpy:7464
    old "Watch the movie"
    new "Ver la película"

    # C:/Users/NICOLLE/Desktop/novelas visuales/game/day1_2.rpy:7464
    old "Go to the Arcade"
    new "Ir al Arcade"

    # C:/Users/NICOLLE/Desktop/novelas visuales/game/day1_2.rpy:7534
    old "What do you mean? I actually enjoy those as well!"
    new "¿Qué quieres decir? ¡A mí también me gustan!"

    # C:/Users/NICOLLE/Desktop/novelas visuales/game/day1_2.rpy:7534
    old "They're not weird."
    new "No son raros."

    # C:/Users/NICOLLE/Desktop/novelas visuales/game/day1_2.rpy:7655
    old "Go through the window."
    new "Pasar por la ventana."

    # C:/Users/NICOLLE/Desktop/novelas visuales/game/day1_2.rpy:7655
    old "Hold on to the door"
    new "Aférrate a la puerta"

    # C:/Users/NICOLLE/Desktop/novelas visuales/game/day1_2.rpy:7765
    old "I'm not"
    new "No lo estoy"

    # C:/Users/NICOLLE/Desktop/novelas visuales/game/day1_2.rpy:7765
    old "I'm fine..."
    new "Estoy bien..."

    # C:/Users/NICOLLE/Desktop/novelas visuales/game/day1_2.rpy:7943
    old "Cat plushie"
    new "Peluche de gato"

    # C:/Users/NICOLLE/Desktop/novelas visuales/game/day1_2.rpy:7943
    old "Shiba Inu plushie"
    new "Peluche de Shiba Inu"

    # C:/Users/NICOLLE/Desktop/novelas visuales/game/day1_2.rpy:7943
    old "Horse plush"
    new "Peluche de caballo"

    # C:/Users/NICOLLE/Desktop/novelas visuales/game/day1_2.rpy:8089
    old "Thank you for saving me."
    new "Gracias por salvarme."

    # C:/Users/NICOLLE/Desktop/novelas visuales/game/day1_2.rpy:8089
    old "Say nothing."
    new "No decir nada."

    # C:/Users/NICOLLE/Desktop/novelas visuales/game/day1_2.rpy:8167
    old "Agree with Hyugo"
    new "Estar de acuerdo con Hyugo"

    # C:/Users/NICOLLE/Desktop/novelas visuales/game/day1_2.rpy:8167
    old "Let Sol walk you home"
    new "Dejar que Sol te acompañe a casa"

    # C:/Users/NICOLLE/Desktop/novelas visuales/game/day1_2.rpy:8253
    old "Sol"
    new "Sol"

    # C:/Users/NICOLLE/Desktop/novelas visuales/game/day1_2.rpy:8253
    old "Crowe"
    new "Crowe"

    # C:/Users/NICOLLE/Desktop/novelas visuales/game/day1_2.rpy:8344
    old "Is he always like that?"
    new "¿Él siempre es así?"

    # C:/Users/NICOLLE/Desktop/novelas visuales/game/day1_2.rpy:8344
    old "He didn't need to be harsh about it."
    new "No necesitaba ser tan duro al respecto."

    # C:/Users/NICOLLE/Desktop/novelas visuales/game/day1_2.rpy:8438
    old "Kiss his knuckles"
    new "Besar sus nudillos"

    # C:/Users/NICOLLE/Desktop/novelas visuales/game/day1_2.rpy:8438
    old "Let go."
    new "Suelta."

    # C:/Users/NICOLLE/Desktop/novelas visuales/game/day1_2.rpy:8482
    old "Give Sol a nickname."
    new "Dale un apodo a Sol."

    # C:/Users/NICOLLE/Desktop/novelas visuales/game/day1_2.rpy:8482
    old "Don't give him a nickname."
    new "No le des un apodo."

    # C:/Users/NICOLLE/Desktop/novelas visuales/game/day1_2.rpy:8695
    old "Nope"
    new "No"

    # C:/Users/NICOLLE/Desktop/novelas visuales/game/day1_2.rpy:8695
    old "Wait! I thought of something!"
    new "¡Espera! ¡Se me ocurrió algo!"

    # C:/Users/NICOLLE/Desktop/novelas visuales/game/day1_2.rpy:9287
    old "Leave it"
    new "Déjalo"

    # C:/Users/NICOLLE/Desktop/novelas visuales/game/day1_2.rpy:9287
    old "Keep prying it out"
    new "Sigue sacándolo"

    # C:/Users/NICOLLE/Desktop/novelas visuales/game/day1_2.rpy:9361
    old "Tap his shoulder"
    new "Toca su hombro"

    # C:/Users/NICOLLE/Desktop/novelas visuales/game/day1_2.rpy:9361
    old "Crowe?"
    new "¿Crowe?"

    # C:/Users/NICOLLE/Desktop/novelas visuales/game/day1_2.rpy:9406
    old "I see her as a friend"
    new "La veo como amiga"

    # C:/Users/NICOLLE/Desktop/novelas visuales/game/day1_2.rpy:9406
    old "I think nothing of her"
    new "No pienso nada de ella"

    # C:/Users/NICOLLE/Desktop/novelas visuales/game/day1_2.rpy:9406
    old "She's highly suspicious"
    new "Es muy sospechosa"

    # C:/Users/NICOLLE/Desktop/novelas visuales/game/day1_2.rpy:9502
    old "Still believe in the Queen"
    new "Sigo creyendo en la Reina"

    # C:/Users/NICOLLE/Desktop/novelas visuales/game/day1_2.rpy:9502
    old "I would believe the rumors."
    new "Creería en los rumores."

    # C:/Users/NICOLLE/Desktop/novelas visuales/game/day1_2.rpy:9502
    old "I can't answer"
    new "No puedo responder"

    # C:/Users/NICOLLE/Desktop/novelas visuales/game/day1_2.rpy:9696
    old "Let him hold you"
    new "Déjalo que te sostenga"

    # C:/Users/NICOLLE/Desktop/novelas visuales/game/day1_2.rpy:9696
    old "Decline"
    new "Rechazar"

    # C:/Users/NICOLLE/Desktop/novelas visuales/game/day1_2.rpy:10003
    old "Give the cat a name"
    new "Dale un nombre al gato"

    # C:/Users/NICOLLE/Desktop/novelas visuales/game/day1_2.rpy:10003
    old "Let Crowe name it"
    new "Deja que Crowe lo nombre"

    # C:/Users/NICOLLE/Desktop/novelas visuales/game/day1_2.rpy:10095
    old "Unique"
    new "Único"

    # C:/Users/NICOLLE/Desktop/novelas visuales/game/day1_2.rpy:10095
    old "Nerdy"
    new "Nerd"

    # C:/Users/NICOLLE/Desktop/novelas visuales/game/day1_2.rpy:10212
    old "Nonesense!"
    new "¡Disparate!"

    # C:/Users/NICOLLE/Desktop/novelas visuales/game/day1_2.rpy:10212
    old "I mean..."
    new "Quiero decir..."

    old "vagina"
    new "vagina"

    old "pussy"
    new "coño"

    old "penis"
    new "pene"

    old "dick"
    new "polla"

    old "she"
    new "ella"

    old "he"
    new "él"

    old "they"
    new "elle"

    old "them"
    new "elle"

    old "her"
    new "ella"

    old "him"
    new "él"

    old "End Replay"
    new "Fin de Repetición"

    old "About"
    new "Acerca de"

    old "Version [config.version!t]\n"
    new "Versión [config.version!t]\n"

    old "Made with {a=https://www.renpy.org/}Ren'Py{/a} [renpy.version_only].\n\n[renpy.license!t]"
    new "Hecho con {a=https://www.renpy.org/}Ren'Py{/a} [renpy.version_only].\n\n[renpy.license!t]"

    old "The Kid at the Back made by fantasia_kitt"
    new "The Kid at the Back hecho por fantasia_kitt"

    old "SUPPORT FANTASIA_KITT"
    new "APOYA A FANTASIA_KITT"

    old "{a=https://x.com/fantasia_kitt}Twitter/X{/a}|{a=https://www.tumblr.com/blog/fantasia-kitt}Tumblr{/a}|{a=https://www.patreon.com/fantasia_tealcatart}Patreon{/a}"
    new "{a=https://x.com/fantasia_kitt}Twitter/X{/a}|{a=https://www.tumblr.com/blog/fantasia-kitt}Tumblr{/a}|{a=https://www.patreon.com/fantasia_tealcatart}Patreon{/a}"

    old "CONTENT WARNINGS"
    new "ADVERTENCIAS DE CONTENIDO"

    old "Content Warnings"
    new "Advertencias"

    old "NSFW BUILD"
    new "VERSIÓN NSFW"

    old "* Screen Shaking & Motion"
    new "* Temblor de Pantalla y Movimiento"

    old "* Graphic Violence (Blood | Gore | Amputation | Beheadings)"
    new "* Violencia Gráfica (Sangre | Visceras | Amputación | Decapitaciones)"

    old "* Major Character Death"
    new "* Muerte de Personaje Principal"

    old "* Player Character Death"
    new "* Muerte del Personaje del Jugador"

    old "* Usage of Weapons (Guns and Pistols | Sharp Objects and Knives)"
    new "* Uso de Armas (Pistolas y Revólveres | Objetos Afilados y Cuchillos)"

    old "* Drugging"
    new "* Drogado"

    old "* Somnophilia"
    new "* Somnofilia"

    old "* Non-Consensual Sex (Mild to High)"
    new "* Sexo No Consensual (Leve a Alto)"

    old "* Implied Child Neglect and Abuse"
    new "* Abandono y Abuso Infantil Implícito"

    old "* Public Sex"
    new "* Sexo Público"

    old "* Public and Private Masturbation"
    new "* Masturbación Pública y Privada"

    old " If you are uncomfortable with the warnings listed above then please {color=#ff0000}exit the game{/color}."
    new " Si te sientes incómodo con las advertencias listadas arriba, por favor {color=#ff0000}sal del juego{/color}."

    old "See full content warnings through this {a=https://tkatbwarnings.carrd.co}link{/a}"
    new "Ve las advertencias de contenido completas a través de este {a=https://tkatbwarnings.carrd.co}enlace{/a}"

    old "DISCLAIMERS"
    new "DESCARGOS DE RESPONSABILIDAD"

    old "This game is still in its development stage so there might be potential errors both grammar and code wise. If you encoutner any grammar errors and/or bugs, please do send it through this {a=https://forms.gle/LUNEKtQ5wG3HRHU39}link{/a}."
    new "Este juego todavía está en su etapa de desarrollo, por lo que podría haber errores potenciales tanto gramaticales como de código. Si encuentras errores gramaticales y/o bugs, por favor envíalos a través de este {a=https://forms.gle/LUNEKtQ5wG3HRHU39}enlace{/a}."

    old "If you have questions you would like to ask me, the creator, please do send me an {a=https://fantasiakitt.carrd.co/#contact}e-mail{/a}.\n"
    new "Si tienes preguntas que quieras hacerme, al creador, por favor envíame un {a=https://fantasiakitt.carrd.co/#contact}correo electrónico{/a}.\n"

    old "Minors are strictly prohibited from playing this game or engaging in any shape of form of the game. This game is a work of fiction, anything in this game is fiction and not based off on any real life events. Discretion is Advised\n"
    new "Los menores tienen estrictamente prohibido jugar este juego o participar en cualquier forma del juego. Este juego es una obra de ficción, todo en este juego es ficción y no se basa en eventos de la vida real. Se recomienda discreción\n"

    old "In no way, shape or form, the creator condones or accepts the illegal and horrible actions shown in-game made \nby the characters. This visual novel is made for creative venture and is pure fiction and should not be romanticize or \nreplicated in real life. \n\nIf anything comes harm to you in real life, please call your {a=https://www.dt.com/ca/wp-content/uploads/2017/03/Global-_911_Emergency-Contacts.pdf}local emergency hotline{/a}. Stay safe!"
    new "De ninguna manera, forma o modo, el creador condona o acepta las acciones ilegales y horribles mostradas en el juego hechas \npor los personajes. Esta novela visual se hizo para un emprendimiento creativo y es pura ficción y no debe romantizarse ni \nreplicarse en la vida real. \n\nSi algo te causa daño en la vida real, por favor llama a tu {a=https://www.dt.com/ca/wp-content/uploads/2017/03/Global-_911_Emergency-Contacts.pdf}línea de emergencia local{/a}. ¡Mantente seguro!"

    old "Save"
    new "Guardar"

    old "Load"
    new "Cargar"

    old "| Page {} |"
    new "| Página {} |"
    
    old "Automatic saves"
    new "Guardados automáticos"

    old "Quick saves"
    new "Guardados rápidos"

    old "{#file_time}%A, %B %d %Y, %H:%M"
    new "{#file_time}%A, %d de %B de %Y, %H:%M"

    old "empty slot"
    new "ranura vacía"

    old "Previous"
    new "Anterior"

    old "{#auto_page}A"
    new "{#auto_page}A"

    old "{#quick_page}Q"
    new "{#quick_page}R"

    old "Next"
    new "Siguiente"
    
    old "Preferences"
    new "Preferencias"

    old "Preference"
    new "Preferencias"

    old "Display"
    new "Pantalla"

    old "Window"
    new "Ventana"

    old "Fullscreen"
    new "Pantalla completa"

    old "Skip"
    new "Saltar"

    old "Unseen Text"
    new "Texto no visto"

    old "After Choices"
    new "Después de Elecciones"

    old "Transitions"
    new "Transiciones"

    old "NSFW Scenes"
    new "Escenas NSFW"

    old "On"
    new "Si"

    old "Off"
    new "No"

    old "Text Speed"
    new "Velocidad de Texto"

    old "Auto-Forward Time"
    new "Tiempo de Avance Automático"

    old "Music Volume"
    new "Volumen de Música"

    old "Sound Volume"
    new "Volumen de Sonido"

    old "Test"
    new "Prueba"

    old "Voice Volume"
    new "Volumen de Voz"

    old "Mute All"
    new "Silenciar Todo"

    old "History"
    new "Historial"

    old "The dialogue history is empty."
    new "El historial de diálogo está vacío."

    old "Help"
    new "Ayuda"

    old "Keyboard"
    new "Teclado"

    old "Mouse"
    new "Ratón"

    old "Gamepad"
    new "Mando"

    old "Enter"
    new "Enter"

    old "Advances dialogue and activates the interface."
    new "Avanza el diálogo y activa la interfaz."

    old "Space"
    new "Espacio"

    old "Advances dialogue without selecting choices."
    new "Avanza el diálogo sin seleccionar opciones."

    old "Arrow Keys"
    new "Teclas de Flecha"

    old "Navigate the interface."
    new "Navega la interfaz."

    old "Escape"
    new "Escape"

    old "Accesses the game menu."
    new "Accede al menú del juego."

    old "Ctrl"
    new "Ctrl"

    old "Skips dialogue while held down."
    new "Salta el diálogo mientras se mantiene presionado."

    old "Tab"
    new "Tab"

    old "Toggles dialogue skipping."
    new "Alterna el salto de diálogo."

    old "Page Up"
    new "Página Arriba"

    old "Rolls back to earlier dialogue."
    new "Retrocede a diálogo anterior."

    old "Page Down"
    new "Página Abajo"

    old "Rolls forward to later dialogue."
    new "Avanza a diálogo posterior."

    old "Hides the user interface."
    new "Oculta la interfaz de usuario."

    old "Takes a screenshot."
    new "Toma una captura de pantalla."

    old "Toggles assistive {a=https://www.renpy.org/l/voicing}self-voicing{/a}."
    new "Alterna la {a=https://www.renpy.org/l/voicing}autovoz asistida{/a}."

    old "Opens the accessibility menu."
    new "Abre el menú de accesibilidad."

    old "Left Click"
    new "Clic Izquierdo"

    old "Middle Click"
    new "Clic Medio"

    old "Right Click"
    new "Clic Derecho"

    old "Mouse Wheel Up\nClick Rollback Side"
    new "Rueda del Ratón Arriba\nClic Lado de Retroceso"

    old "Mouse Wheel Down"
    new "Rueda del Ratón Abajo"

    old "Right Trigger\nA/Bottom Button"
    new "Gatillo Derecho\nA/Botón Inferior"

    old "Left Trigger\nLeft Shoulder"
    new "Gatillo Izquierdo\nHombro Izquierdo"

    old "Right Shoulder"
    new "Hombro Derecho"

    old "D-Pad, Sticks"
    new "D-Pad, Palancas"

    old "Start"
    new "Iniciar"

    old "Y/Top Button"
    new "Y/Botón Superior"

    old "Calibrate"
    new "Calibrar"

    old "Skipping"
    new "Saltando"

    old "Quit"
    new "Quitar"

    old "Return"
    new "Volver"

    old "RETURN"
    new "VOLVER"

    old "A game by fantasia_kitt presents..."
    new "Un juego de fantasia_kitt presenta..."

    old "The Kid at the Back"
    new "The Kid at the Back"

    old "DISCLAIMER"
    new "ADVERTENCIA"

    old "The Kid at the Back is a thriller/horror Visual Novel with romantic elements but it is not to be treated like a regular romance novel. Minors are strictly prohibited from playing this game or engaging in any shape of form of the game. The creator does not condone or accepts the illegal and horrible actions shown in-game made by the characters in any way shape or form. \n\nThis visual novel is made for creative venture and is pure fiction and should not be romanticize or replicated in real life."
    new "The Kid at the Backes una novela visual de suspenso/terror con elementos románticos, pero no debe ser tratada como una novela romántica común. Los menores tienen estrictamente prohibido jugar este juego o participar de cualquier forma en él. El creador no aprueba ni acepta las acciones ilegales y horribles mostradas en el juego por los personajes de ninguna manera. \n\nEsta novela visual se creó como una iniciativa creativa, es pura ficción y no debe romanticizarse ni replicarse en la vida real."

    old "This game includes explicit and dark themes such as major character death to both the characters and the player, murder, sexual assault, non-consensual touching/sex, implied abuse, bullying, usage of firearms and weapons (guns, swords, sharp weapons), drugging, violence and more. To see a more detailed list of triggers, please click this {a=https://tkatbwarnings.carrd.co}link{/a}."
    new "Este juego incluye temas explícitos y oscuros, como la muerte de personajes principales, asesinato, agresión sexual, tocamientos/sexo no consensuado, abuso implícito, acoso, uso de armas de fuego y otras armas (pistolas, espadas, armas cortantes), drogadicción, violencia y más. Para ver una lista más detallada de detonantes, haz clic en este {a=https://tkatbwarnings.carrd.co}enlace{/a}."

    old "The Kid at the Back is intended for mature audiences only."
    new "The Kid at the Back está destinado únicamente a audiencias maduras."

    old "Viewer discretion is advised."
    new "Se recomienda discreción del espectador."

    old "I am over 18 and consent to play"
    new "Tengo más de 18 años"

    old "I am under 18 or do not consent"
    new "Tengo menos de 18 años"

    old "{color=#f00}{b}WARNING + DISCLAIMER{/b}{/color}\n \n{i}This game is rated 18+{/i} \n Minors are strictly prohibited from playing this game or engaging in any shape of form of the game.{i}\n This game is a work of fiction, anything in this game is fiction and not based off on any real life events \n Discretion is Advised.{/i}"
    new "{color=#f00}{b}ADVERTENCIA + AVISO{/b}{/color}\n \n{i}Este juego es para mayores de 18 años{/i} \n Los menores tienen estrictamente prohibido jugar este juego o participar de cualquier forma en él.{i}\n Este juego es una obra de ficción, todo en este juego es ficción y no se basa en hechos de la vida real \n Se recomienda discreción.{/i}"

    old "Main Menu"
    new "Menu principal"

    old "Red-Haired Bully"
    new "Bully Pelirrojo"

    old "Blonde Bully"
    new "Bully Rubio"

    old "Ravenette Bully"
    new "Bully Moreno"

    old "Nurse"
    new "Enfermera"

    old "Professor"
    new "Profesor"

    old "Raven-Haired Bully"
    new "Bully Moreno"

    old "Librarian"
    new "Bibliotecario"

    old "Barista"
    new "Barista"

    old "Rough Voice"
    new "Voz Grave"

    old "Meek Voice"
    new "Voz Suave"

    old "Young Man"
    new "Joven"

    old "Tall Young man"
    new "Joven Alto"

    old "Reporter"
    new "Reportero"

    old "Oogami Member"
    new "Miembro Oogami"

    old "Father"
    new "Padre"

    old "Student"
    new "Estudiante"

    old "Mr. Z"
    new "Sr. Z"
