# TODO: Translation updated at 2026-09-27 20:49

translate spanish strings:

    # renpy/common/000statements.rpy:28
    old "Click to play the video."
    new "Haz clic para reproducir el video."

    # renpy/common/00accessibility.rpy:28
    old "Self-voicing disabled."
    new "Lectura automática desactivada."

    # renpy/common/00accessibility.rpy:29
    old "Clipboard voicing enabled. "
    new "Lectura desde el portapapeles activada. "

    # renpy/common/00accessibility.rpy:30
    old "Self-voicing enabled. "
    new "Lectura automática activada. "

    # renpy/common/00accessibility.rpy:32
    old "bar"
    new "barra"

    # renpy/common/00accessibility.rpy:33
    old "selected"
    new "seleccionado"

    # renpy/common/00accessibility.rpy:34
    old "viewport"
    new "área de visualización"

    # renpy/common/00accessibility.rpy:35
    old "horizontal scroll"
    new "desplazamiento horizontal"

    # renpy/common/00accessibility.rpy:36
    old "vertical scroll"
    new "desplazamiento vertical"

    # renpy/common/00accessibility.rpy:37
    old "activate"
    new "activar"

    # renpy/common/00accessibility.rpy:38
    old "deactivate"
    new "desactivar"

    # renpy/common/00accessibility.rpy:39
    old "increase"
    new "aumentar"

    # renpy/common/00accessibility.rpy:40
    old "decrease"
    new "disminuir"

    # renpy/common/00accessibility.rpy:134
    old "Self-Voicing"
    new "Lectura automática"

    # renpy/common/00accessibility.rpy:137
    old "Self-voicing support is limited when using a touch screen."
    new "La compatibilidad con la lectura automática es limitada al usar una pantalla táctil."

    # renpy/common/00accessibility.rpy:139
    old "Off"
    new "No"

    # renpy/common/00accessibility.rpy:143
    old "Text-to-speech"
    new "Texto a voz"

    # renpy/common/00accessibility.rpy:147
    old "Clipboard"
    new "Portapapeles"

    # renpy/common/00accessibility.rpy:151
    old "Debug"
    new "Depuración"

    # renpy/common/00accessibility.rpy:163
    old "Reset"
    new "Restablecer"

    # renpy/common/00accessibility.rpy:167
    old "Self-Voicing Volume Drop"
    new "Reducción del volumen de la lectura automática"

    # renpy/common/00accessibility.rpy:180
    old "Mono Audio"
    new "Audio mono"

    # renpy/common/00accessibility.rpy:182
    old "Enable"
    new "Activar"

    # renpy/common/00accessibility.rpy:186
    old "Disable"
    new "Desactivar"

    # renpy/common/00accessibility.rpy:198
    old "Font Override"
    new "Anulación de fuente"

    # renpy/common/00accessibility.rpy:200
    old "Default"
    new "Predeterminada"

    # renpy/common/00accessibility.rpy:204
    old "DejaVu Sans"
    new "DejaVu Sans"

    # renpy/common/00accessibility.rpy:208
    old "Opendyslexic"
    new "Opendyslexic"

    # renpy/common/00accessibility.rpy:212
    old "High Contrast Text"
    new "Texto de alto contraste"

    # renpy/common/00accessibility.rpy:224
    old "Text Size Scaling"
    new "Escala del tamaño del texto"

    # renpy/common/00accessibility.rpy:235
    old "Line Spacing Scaling"
    new "Escala del espaciado entre líneas"

    # renpy/common/00accessibility.rpy:246
    old "Kerning"
    new "Interletraje"

    # renpy/common/00accessibility.rpy:267
    old "Accessibility Menu. Use up and down arrows to navigate, and enter to activate buttons and bars."
    new "Menú de accesibilidad. Usa las flechas arriba y abajo para navegar y Enter para activar botones y barras."

    # renpy/common/00accessibility.rpy:288
    old "Self-Voicing and Audio"
    new "Lectura automática y audio"

    # renpy/common/00accessibility.rpy:292
    old "Text"
    new "Texto"

    # renpy/common/00accessibility.rpy:296
    old "Return"
    new "Volver"

    # renpy/common/00accessibility.rpy:306
    old "The options on this menu are intended to improve accessibility. They may not work with all games, and some combinations of options may render the game unplayable. This is not an issue with the game or engine. For the best results when changing fonts, try to keep the text size the same as it originally was."
    new "Las opciones de este menú están destinadas a mejorar la accesibilidad. Es posible que no funcionen con todos los juegos y que algunas combinaciones de opciones hagan que el juego sea imposible de jugar. Esto no es un problema del juego ni del motor. Para obtener los mejores resultados al cambiar de fuente, intenta mantener el mismo tamaño de texto que tenía originalmente."

    # renpy/common/00action_file.rpy:26
    old "{#weekday}Monday"
    new "{#weekday}Lunes"

    # renpy/common/00action_file.rpy:26
    old "{#weekday}Tuesday"
    new "{#weekday}Martes"

    # renpy/common/00action_file.rpy:26
    old "{#weekday}Wednesday"
    new "{#weekday}Miércoles"

    # renpy/common/00action_file.rpy:26
    old "{#weekday}Thursday"
    new "{#weekday}Jueves"

    # renpy/common/00action_file.rpy:26
    old "{#weekday}Friday"
    new "{#weekday}Viernes"

    # renpy/common/00action_file.rpy:26
    old "{#weekday}Saturday"
    new "{#weekday}Sábado"

    # renpy/common/00action_file.rpy:26
    old "{#weekday}Sunday"
    new "{#weekday}Domingo"

    # renpy/common/00action_file.rpy:37
    old "{#weekday_short}Mon"
    new "{#weekday_short}Lun"

    # renpy/common/00action_file.rpy:37
    old "{#weekday_short}Tue"
    new "{#weekday_short}Mar"

    # renpy/common/00action_file.rpy:37
    old "{#weekday_short}Wed"
    new "{#weekday_short}Mié"

    # renpy/common/00action_file.rpy:37
    old "{#weekday_short}Thu"
    new "{#weekday_short}Jue"

    # renpy/common/00action_file.rpy:37
    old "{#weekday_short}Fri"
    new "{#weekday_short}Vie"

    # renpy/common/00action_file.rpy:37
    old "{#weekday_short}Sat"
    new "{#weekday_short}Sáb"

    # renpy/common/00action_file.rpy:37
    old "{#weekday_short}Sun"
    new "{#weekday_short}Dom"

    # renpy/common/00action_file.rpy:47
    old "{#month}January"
    new "{#month}Enero"

    # renpy/common/00action_file.rpy:47
    old "{#month}February"
    new "{#month}Febrero"

    # renpy/common/00action_file.rpy:47
    old "{#month}March"
    new "{#month}Marzo"

    # renpy/common/00action_file.rpy:47
    old "{#month}April"
    new "{#month}Abril"

    # renpy/common/00action_file.rpy:47
    old "{#month}May"
    new "{#month}Mayo"

    # renpy/common/00action_file.rpy:47
    old "{#month}June"
    new "{#month}Junio"

    # renpy/common/00action_file.rpy:47
    old "{#month}July"
    new "{#month}Julio"

    # renpy/common/00action_file.rpy:47
    old "{#month}August"
    new "{#month}Agosto"

    # renpy/common/00action_file.rpy:47
    old "{#month}September"
    new "{#month}Septiembre"

    # renpy/common/00action_file.rpy:47
    old "{#month}October"
    new "{#month}Octubre"

    # renpy/common/00action_file.rpy:47
    old "{#month}November"
    new "{#month}Noviembre"

    # renpy/common/00action_file.rpy:47
    old "{#month}December"
    new "{#month}Diciembre"

    # renpy/common/00action_file.rpy:63
    old "{#month_short}Jan"
    new "{#month_short}Ene"

    # renpy/common/00action_file.rpy:63
    old "{#month_short}Feb"
    new "{#month_short}Feb"

    # renpy/common/00action_file.rpy:63
    old "{#month_short}Mar"
    new "{#month_short}Mar"

    # renpy/common/00action_file.rpy:63
    old "{#month_short}Apr"
    new "{#month_short}Abr"

    # renpy/common/00action_file.rpy:63
    old "{#month_short}May"
    new "{#month_short}May"

    # renpy/common/00action_file.rpy:63
    old "{#month_short}Jun"
    new "{#month_short}Jun"

    # renpy/common/00action_file.rpy:63
    old "{#month_short}Jul"
    new "{#month_short}Jul"

    # renpy/common/00action_file.rpy:63
    old "{#month_short}Aug"
    new "{#month_short}Ago"

    # renpy/common/00action_file.rpy:63
    old "{#month_short}Sep"
    new "{#month_short}Sep"

    # renpy/common/00action_file.rpy:63
    old "{#month_short}Oct"
    new "{#month_short}Oct"

    # renpy/common/00action_file.rpy:63
    old "{#month_short}Nov"
    new "{#month_short}Nov"

    # renpy/common/00action_file.rpy:63
    old "{#month_short}Dec"
    new "{#month_short}Dic"

    # renpy/common/00action_file.rpy:258
    old "%b %d, %H:%M"
    new "%b %d, %H:%M"

    # renpy/common/00action_file.rpy:395
    old "Save slot %s: [text]"
    new "Ranura de guardado %s: [text]"

    # renpy/common/00action_file.rpy:481
    old "Load slot %s: [text]"
    new "Cargar ranura %s: [text]"

    # renpy/common/00action_file.rpy:534
    old "Delete slot [text]"
    new "Eliminar ranura [text]"

    # renpy/common/00action_file.rpy:613
    old "File page auto"
    new "Página de guardado automático"

    # renpy/common/00action_file.rpy:615
    old "File page quick"
    new "Página de guardado rápido"

    # renpy/common/00action_file.rpy:617
    old "File page [text]"
    new "Página de guardado [text]"

    # renpy/common/00action_file.rpy:675
    old "Page {}"
    new "Página {}"

    # renpy/common/00action_file.rpy:816
    old "Next file page."
    new "Página de guardados siguiente."

    # renpy/common/00action_file.rpy:888
    old "Previous file page."
    new "Página de guardados anterior."

    # renpy/common/00action_file.rpy:949
    old "Quick save complete."
    new "Guardado rápido completado."

    # renpy/common/00action_file.rpy:964
    old "Quick save."
    new "Guardado rápido."

    # renpy/common/00action_file.rpy:983
    old "Quick load."
    new "Carga rápida."

    # renpy/common/00action_other.rpy:416
    old "Language [text]"
    new "Idioma [text]"

    # renpy/common/00action_other.rpy:786
    old "Open [text] directory."
    new "Abrir el directorio [text]."

    # renpy/common/00director.rpy:712
    old "The interactive director is not enabled here."
    new "El director interactivo no está habilitado aquí."

    # renpy/common/00director.rpy:1512
    old "⬆"
    new "⬆"

    # renpy/common/00director.rpy:1518
    old "⬇"
    new "⬇"

    # renpy/common/00director.rpy:1582
    old "Done"
    new "Listo"

    # renpy/common/00director.rpy:1592
    old "(statement)"
    new "(instrucción)"

    # renpy/common/00director.rpy:1593
    old "(tag)"
    new "(etiqueta)"

    # renpy/common/00director.rpy:1594
    old "(attributes)"
    new "(atributos)"

    # renpy/common/00director.rpy:1595
    old "(transform)"
    new "(transformación)"

    # renpy/common/00director.rpy:1620
    old "(transition)"
    new "(transición)"

    # renpy/common/00director.rpy:1632
    old "(channel)"
    new "(canal)"

    # renpy/common/00director.rpy:1633
    old "(filename)"
    new "(nombre de archivo)"

    # renpy/common/00director.rpy:1662
    old "Change"
    new "Cambiar"

    # renpy/common/00director.rpy:1664
    old "Add"
    new "Añadir"

    # renpy/common/00director.rpy:1667
    old "Cancel"
    new "Cancelar"

    # renpy/common/00director.rpy:1670
    old "Remove"
    new "Eliminar"

    # renpy/common/00director.rpy:1705
    old "Statement:"
    new "Instrucción:"

    # renpy/common/00director.rpy:1726
    old "Tag:"
    new "Etiqueta:"

    # renpy/common/00director.rpy:1742
    old "Attributes:"
    new "Atributos:"

    # renpy/common/00director.rpy:1753
    old "Click to toggle attribute, right click to toggle negative attribute."
    new "Haz clic para activar o desactivar el atributo; haz clic derecho para activar o desactivar el atributo negativo."

    # renpy/common/00director.rpy:1765
    old "Transforms:"
    new "Transformaciones:"

    # renpy/common/00director.rpy:1776
    old "Click to set transform, right click to add to transform list."
    new "Haz clic para establecer la transformación; haz clic derecho para añadirla a la lista de transformaciones."

    # renpy/common/00director.rpy:1777
    old "Customize director.transforms to add more transforms."
    new "Personaliza director.transforms para añadir más transformaciones."

    # renpy/common/00director.rpy:1789
    old "Behind:"
    new "Detrás:"

    # renpy/common/00director.rpy:1800
    old "Click to set, right click to add to behind list."
    new "Haz clic para establecerlo; haz clic derecho para añadirlo a la lista de elementos detrás."

    # renpy/common/00director.rpy:1812
    old "Transition:"
    new "Transición:"

    # renpy/common/00director.rpy:1822
    old "Click to set."
    new "Haz clic para establecerla."

    # renpy/common/00director.rpy:1823
    old "Customize director.transitions to add more transitions."
    new "Personaliza director.transitions para añadir más transiciones."

    # renpy/common/00director.rpy:1835
    old "Channel:"
    new "Canal:"

    # renpy/common/00director.rpy:1846
    old "Customize director.audio_channels to add more channels."
    new "Personaliza director.audio_channels para añadir más canales."

    # renpy/common/00director.rpy:1858
    old "Audio Filename:"
    new "Nombre del archivo de audio:"

    # renpy/common/00gui.rpy:448
    old "Are you sure?"
    new "¿Estás seguro?"

    # renpy/common/00gui.rpy:449
    old "Are you sure you want to delete this save?"
    new "¿Estás seguro de que quieres eliminar este guardado?"

    # renpy/common/00gui.rpy:450
    old "Are you sure you want to overwrite your save?"
    new "¿Estás seguro de que quieres sobrescribir este guardado?"

    # renpy/common/00gui.rpy:451
    old "Loading will lose unsaved progress.\nAre you sure you want to do this?"
    new "Al cargar perderás el progreso no guardado.\n¿Estás seguro de que quieres continuar?"

    # renpy/common/00gui.rpy:452
    old "Are you sure you want to quit?"
    new "¿Estás seguro de que quieres salir?"

    # renpy/common/00gui.rpy:453
    old "Are you sure you want to return to the main menu?\nThis will lose unsaved progress."
    new "¿Estás seguro de que quieres volver al menú principal?\nPerderás el progreso no guardado."

    # renpy/common/00gui.rpy:454
    old "Are you sure you want to continue where you left off?"
    new "¿Estás seguro de que quieres continuar desde donde lo dejaste?"

    # renpy/common/00gui.rpy:455
    old "Are you sure you want to end the replay?"
    new "¿Estás seguro de que quieres terminar la repetición?"

    # renpy/common/00gui.rpy:456
    old "Are you sure you want to begin skipping?"
    new "¿Estás seguro de que quieres comenzar a omitir?"

    # renpy/common/00gui.rpy:457
    old "Are you sure you want to skip to the next choice?"
    new "¿Estás seguro de que quieres saltar hasta la siguiente elección?"

    # renpy/common/00gui.rpy:458
    old "Are you sure you want to skip unseen dialogue to the next choice?"
    new "¿Estás seguro de que quieres omitir los diálogos no vistos hasta la siguiente elección?"

    # renpy/common/00gui.rpy:459
    old "This save was created on a different device. Maliciously constructed save files can harm your computer. Do you trust this save's creator and everyone who could have changed the file?"
    new "Este guardado se creó en otro dispositivo. Los archivos de guardado creados con fines maliciosos pueden dañar tu computadora. ¿Confías en quien creó este guardado y en todas las personas que podrían haber modificado el archivo?"

    # renpy/common/00gui.rpy:460
    old "Do you trust the device the save was created on? You should only choose yes if you are the device's sole user."
    new "¿Confías en el dispositivo en el que se creó el guardado? Solo debes elegir que sí si eres la única persona que usa el dispositivo."

    # renpy/common/00keymap.rpy:325
    old "Failed to save screenshot as %s."
    new "No se pudo guardar la captura de pantalla como %s."

    # renpy/common/00keymap.rpy:346
    old "Saved screenshot as %s."
    new "Captura de pantalla guardada como %s."

    # renpy/common/00library.rpy:257
    old "Skip Mode"
    new "Modo de omisión"

    # renpy/common/00library.rpy:344
    old "This program contains free software under a number of licenses, including the MIT License and GNU Lesser General Public License. A complete list of software, including links to full source code, can be found {a=https://www.renpy.org/l/license}here{/a}."
    new "Este programa contiene software libre distribuido bajo varias licencias, incluidas la Licencia MIT y la Licencia Pública General Reducida de GNU. Puedes encontrar una lista completa del software, incluidos enlaces al código fuente completo, {a=https://www.renpy.org/l/license}aquí{/a}."

    # renpy/common/00preferences.rpy:295
    old "display"
    new "pantalla"

    # renpy/common/00preferences.rpy:315
    old "transitions"
    new "transiciones"

    # renpy/common/00preferences.rpy:324
    old "skip transitions"
    new "omitir transiciones"

    # renpy/common/00preferences.rpy:326
    old "video sprites"
    new "sprites de video"

    # renpy/common/00preferences.rpy:335
    old "show empty window"
    new "mostrar ventana vacía"

    # renpy/common/00preferences.rpy:344
    old "text speed"
    new "velocidad del texto"

    # renpy/common/00preferences.rpy:352
    old "joystick"
    new "joystick"

    # renpy/common/00preferences.rpy:352
    old "joystick..."
    new "joystick..."

    # renpy/common/00preferences.rpy:359
    old "skip"
    new "omitir"

    # renpy/common/00preferences.rpy:362
    old "skip unseen [text]"
    new "omitir lo no visto [text]"

    # renpy/common/00preferences.rpy:367
    old "skip unseen text"
    new "omitir texto no visto"

    # renpy/common/00preferences.rpy:369
    old "begin skipping"
    new "comenzar a omitir"

    # renpy/common/00preferences.rpy:373
    old "after choices"
    new "después de las elecciones"

    # renpy/common/00preferences.rpy:380
    old "skip after choices"
    new "omitir después de las elecciones"

    # renpy/common/00preferences.rpy:382
    old "auto-forward time"
    new "tiempo de avance automático"

    # renpy/common/00preferences.rpy:396
    old "auto-forward"
    new "avance automático"

    # renpy/common/00preferences.rpy:403
    old "Auto forward"
    new "Avance automático"

    # renpy/common/00preferences.rpy:406
    old "auto-forward after click"
    new "avance automático después de hacer clic"

    # renpy/common/00preferences.rpy:415
    old "automatic move"
    new "movimiento automático"

    # renpy/common/00preferences.rpy:424
    old "wait for voice"
    new "esperar la voz"

    # renpy/common/00preferences.rpy:433
    old "voice sustain"
    new "mantener la voz"

    # renpy/common/00preferences.rpy:442
    old "self voicing"
    new "lectura automática"

    # renpy/common/00preferences.rpy:445
    old "self voicing enable"
    new "activar lectura automática"

    # renpy/common/00preferences.rpy:447
    old "self voicing disable"
    new "desactivar lectura automática"

    # renpy/common/00preferences.rpy:451
    old "self voicing volume drop"
    new "reducción del volumen de la lectura automática"

    # renpy/common/00preferences.rpy:459
    old "clipboard voicing"
    new "lectura desde el portapapeles"

    # renpy/common/00preferences.rpy:462
    old "clipboard voicing enable"
    new "activar lectura desde el portapapeles"

    # renpy/common/00preferences.rpy:464
    old "clipboard voicing disable"
    new "desactivar lectura desde el portapapeles"

    # renpy/common/00preferences.rpy:468
    old "debug voicing"
    new "lectura de depuración"

    # renpy/common/00preferences.rpy:471
    old "debug voicing enable"
    new "activar lectura de depuración"

    # renpy/common/00preferences.rpy:473
    old "debug voicing disable"
    new "desactivar lectura de depuración"

    # renpy/common/00preferences.rpy:477
    old "emphasize audio"
    new "enfatizar audio"

    # renpy/common/00preferences.rpy:486
    old "rollback side"
    new "lado de retroceso"

    # renpy/common/00preferences.rpy:496
    old "gl powersave"
    new "ahorro de energía GL"

    # renpy/common/00preferences.rpy:502
    old "gl framerate"
    new "frecuencia de fotogramas GL"

    # renpy/common/00preferences.rpy:505
    old "gl tearing"
    new "desgarro de imagen GL"

    # renpy/common/00preferences.rpy:508
    old "font transform"
    new "transformación de fuente"

    # renpy/common/00preferences.rpy:511
    old "font size"
    new "tamaño de fuente"

    # renpy/common/00preferences.rpy:519
    old "font line spacing"
    new "espaciado entre líneas de la fuente"

    # renpy/common/00preferences.rpy:527
    old "system cursor"
    new "cursor del sistema"

    # renpy/common/00preferences.rpy:536
    old "renderer menu"
    new "menú del renderizador"

    # renpy/common/00preferences.rpy:539
    old "accessibility menu"
    new "menú de accesibilidad"

    # renpy/common/00preferences.rpy:542
    old "high contrast text"
    new "texto de alto contraste"

    # renpy/common/00preferences.rpy:551
    old "audio when minimized"
    new "audio cuando está minimizado"

    # renpy/common/00preferences.rpy:560
    old "audio when unfocused"
    new "audio cuando no está enfocado"

    # renpy/common/00preferences.rpy:569
    old "web cache preload"
    new "precarga de caché web"

    # renpy/common/00preferences.rpy:584
    old "voice after game menu"
    new "voz después del menú del juego"

    # renpy/common/00preferences.rpy:593
    old "restore window position"
    new "restaurar posición de la ventana"

    # renpy/common/00preferences.rpy:602
    old "mono audio"
    new "audio mono"

    # renpy/common/00preferences.rpy:611
    old "font kerning"
    new "interletraje de fuente"

    # renpy/common/00preferences.rpy:619
    old "reset"
    new "restablecer"

    # renpy/common/00preferences.rpy:632
    old "main volume"
    new "volumen principal"

    # renpy/common/00preferences.rpy:633
    old "music volume"
    new "volumen de música"

    # renpy/common/00preferences.rpy:634
    old "sound volume"
    new "volumen de sonido"

    # renpy/common/00preferences.rpy:635
    old "voice volume"
    new "volumen de voz"

    # renpy/common/00preferences.rpy:636
    old "mute main"
    new "silenciar volumen principal"

    # renpy/common/00preferences.rpy:637
    old "mute music"
    new "silenciar música"

    # renpy/common/00preferences.rpy:638
    old "mute sound"
    new "silenciar sonidos"

    # renpy/common/00preferences.rpy:639
    old "mute voice"
    new "silenciar voz"

    # renpy/common/00preferences.rpy:640
    old "mute all"
    new "silenciar todo"

    # renpy/common/00preferences.rpy:723
    old "Clipboard voicing enabled. Press 'shift+C' to disable."
    new "Lectura desde el portapapeles activada. Pulsa 'shift+C' para desactivarla."

    # renpy/common/00preferences.rpy:725
    old "Self-voicing would say \"[renpy.display.tts.last]\". Press 'alt+shift+V' to disable."
    new "La lectura automática diría \"[renpy.display.tts.last]\". Pulsa 'alt+shift+V' para desactivarla."

    # renpy/common/00preferences.rpy:727
    old "Self-voicing enabled. Press 'v' to disable."
    new "Lectura automática activada. Pulsa 'v' para desactivarla."

    # renpy/common/00speechbubble.rpy:420
    old "Speech Bubble Editor"
    new "Editor de globos de diálogo"

    # renpy/common/00speechbubble.rpy:425
    old "(hide)"
    new "(ocultar)"

    # renpy/common/00speechbubble.rpy:436
    old "(clear retained bubbles)"
    new "(borrar globos conservados)"

    # renpy/common/00sync.rpy:70
    old "Sync downloaded."
    new "Sincronización descargada."

    # renpy/common/00sync.rpy:184
    old "Could not connect to the Ren'Py Sync server."
    new "No se pudo conectar al servidor de sincronización de Ren'Py."

    # renpy/common/00sync.rpy:186
    old "The Ren'Py Sync server timed out."
    new "Se agotó el tiempo de espera del servidor de sincronización de Ren'Py."

    # renpy/common/00sync.rpy:188
    old "An unknown error occurred while connecting to the Ren'Py Sync server."
    new "Se produjo un error desconocido al conectarse al servidor de sincronización de Ren'Py."

    # renpy/common/00sync.rpy:204
    old "The Ren'Py Sync server does not have a copy of this sync. The sync ID may be invalid, or it may have timed out."
    new "El servidor de sincronización de Ren'Py no tiene una copia de esta sincronización. Es posible que el ID de sincronización no sea válido o que haya caducado."

    # renpy/common/00sync.rpy:305
    old "Please enter the sync ID you generated.\nNever enter a sync ID you didn't create yourself."
    new "Introduce el ID de sincronización que generaste.\nNunca introduzcas un ID de sincronización que no hayas creado tú mismo."

    # renpy/common/00sync.rpy:324
    old "The sync ID is not in the correct format."
    new "El ID de sincronización no tiene el formato correcto."

    # renpy/common/00sync.rpy:344
    old "The sync could not be decrypted."
    new "No se pudo descifrar la sincronización."

    # renpy/common/00sync.rpy:367
    old "The sync belongs to a different game."
    new "La sincronización pertenece a otro juego."

    # renpy/common/00sync.rpy:372
    old "The sync contains a file with an invalid name."
    new "La sincronización contiene un archivo con un nombre no válido."

    # renpy/common/00sync.rpy:425
    old "This will upload your saves to the {a=https://sync.renpy.org}Ren'Py Sync Server{/a}.\nDo you want to continue?"
    new "Esto subirá tus partidas guardadas al {a=https://sync.renpy.org}servidor de sincronización de Ren'Py{/a}.\n¿Quieres continuar?"

    # renpy/common/00sync.rpy:457
    old "Enter Sync ID"
    new "Introducir ID de sincronización"

    # renpy/common/00sync.rpy:468
    old "This will contact the {a=https://sync.renpy.org}Ren'Py Sync Server{/a}."
    new "Esto se pondrá en contacto con el {a=https://sync.renpy.org}servidor de sincronización de Ren'Py{/a}."

    # renpy/common/00sync.rpy:498
    old "Sync Success"
    new "Sincronización exitosa"

    # renpy/common/00sync.rpy:501
    old "The Sync ID is:"
    new "El ID de sincronización es:"

    # renpy/common/00sync.rpy:507
    old "You can use this ID to download your save on another device.\nThis sync will expire in an hour.\nRen'Py Sync is supported by {a=https://www.renpy.org/sponsors.html}Ren'Py's Sponsors{/a}."
    new "Puedes usar este ID para descargar tu partida guardada en otro dispositivo.\nEsta sincronización caducará en una hora.\nRen'Py Sync cuenta con el apoyo de los {a=https://www.renpy.org/sponsors.html}patrocinadores de Ren'Py{/a}."

    # renpy/common/00sync.rpy:511
    old "Continue"
    new "Continuar"

    # renpy/common/00sync.rpy:536
    old "Sync Error"
    new "Error de sincronización"

    # renpy/common/00translation.rpy:63
    old "Translation identifier: [identifier]"
    new "Identificador de traducción: [identifier]"

    # renpy/common/00translation.rpy:84
    old " translates [tl.filename]:[tl.linenumber]"
    new " traduce [tl.filename]:[tl.linenumber]"

    # renpy/common/00translation.rpy:101
    old "\n{color=#fff}Copied to clipboard.{/color}"
    new "\n{color=#fff}Copiado al portapapeles.{/color}"

    # renpy/common/00iap.rpy:231
    old "Contacting App Store\nPlease Wait..."
    new "Conectando con la App Store\nEspera..."

    # renpy/common/00updater.rpy:415
    old "No update methods found."
    new "No se encontraron métodos de actualización."

    # renpy/common/00updater.rpy:462
    old "Could not download file list: "
    new "No se pudo descargar la lista de archivos: "

    # renpy/common/00updater.rpy:465
    old "File list digest does not match."
    new "La suma de comprobación de la lista de archivos no coincide."

    # renpy/common/00updater.rpy:675
    old "An error is being simulated."
    new "Se está simulando un error."

    # renpy/common/00updater.rpy:863
    old "Either this project does not support updating, or the update status file was deleted."
    new "Este proyecto no admite actualizaciones o se eliminó el archivo de estado de actualización."

    # renpy/common/00updater.rpy:877
    old "This account does not have permission to perform an update."
    new "Esta cuenta no tiene permiso para realizar una actualización."

    # renpy/common/00updater.rpy:880
    old "This account does not have permission to write the update log."
    new "Esta cuenta no tiene permiso para escribir el registro de actualización."

    # renpy/common/00updater.rpy:966
    old "Could not verify update signature."
    new "No se pudo verificar la firma de la actualización."

    # renpy/common/00updater.rpy:1289
    old "The update file was not downloaded."
    new "El archivo de actualización no se descargó."

    # renpy/common/00updater.rpy:1307
    old "The update file does not have the correct digest - it may have been corrupted."
    new "El archivo de actualización no tiene la suma de comprobación correcta; es posible que esté dañado."

    # renpy/common/00updater.rpy:1457
    old "While unpacking {}, unknown type {}."
    new "Al descomprimir {}, se encontró un tipo desconocido {}."

    # renpy/common/00updater.rpy:1928
    old "Updater"
    new "Actualizador"

    # renpy/common/00updater.rpy:1935
    old "An error has occurred:"
    new "Se ha producido un error:"

    # renpy/common/00updater.rpy:1937
    old "Checking for updates."
    new "Buscando actualizaciones."

    # renpy/common/00updater.rpy:1939
    old "This program is up to date."
    new "Este programa está actualizado."

    # renpy/common/00updater.rpy:1941
    old "[u.version] is available. Do you want to install it?"
    new "[u.version] está disponible. ¿Quieres instalarla?"

    # renpy/common/00updater.rpy:1943
    old "Preparing to download the updates."
    new "Preparándose para descargar las actualizaciones."

    # renpy/common/00updater.rpy:1945
    old "Downloading the updates."
    new "Descargando las actualizaciones."

    # renpy/common/00updater.rpy:1947
    old "Unpacking the updates."
    new "Descomprimiendo las actualizaciones."

    # renpy/common/00updater.rpy:1949
    old "Finishing up."
    new "Finalizando."

    # renpy/common/00updater.rpy:1951
    old "The updates have been installed. The program will restart."
    new "Las actualizaciones se han instalado. El programa se reiniciará."

    # renpy/common/00updater.rpy:1953
    old "The updates have been installed."
    new "Las actualizaciones se han instalado."

    # renpy/common/00updater.rpy:1955
    old "The updates were cancelled."
    new "Las actualizaciones se cancelaron."

    # renpy/common/00updater.rpy:1970
    old "Proceed"
    new "Continuar"

    # renpy/common/00updater.rpy:1986
    old "Preparing to download the game data."
    new "Preparándose para descargar los datos del juego."

    # renpy/common/00updater.rpy:1988
    old "Downloading the game data."
    new "Descargando los datos del juego."

    # renpy/common/00updater.rpy:1990
    old "The game data has been downloaded."
    new "Los datos del juego se han descargado."

    # renpy/common/00updater.rpy:1992
    old "An error occurred when trying to download game data:"
    new "Se produjo un error al intentar descargar los datos del juego:"

    # renpy/common/00updater.rpy:1997
    old "This game cannot be run until the game data has been downloaded."
    new "Este juego no se puede ejecutar hasta que se hayan descargado los datos del juego."

    # renpy/common/00updater.rpy:2004
    old "Retry"
    new "Reintentar"

    # renpy/common/00gallery.rpy:676
    old "Image [index] of [count] locked."
    new "Imagen [index] de [count] bloqueada."

    # renpy/common/00gallery.rpy:696
    old "prev"
    new "ant."

    # renpy/common/00gallery.rpy:697
    old "next"
    new "sig."

    # renpy/common/00gallery.rpy:698
    old "slideshow"
    new "presentación"

    # renpy/common/00gallery.rpy:699
    old "return"
    new "volver"

    # renpy/common/00gltest.rpy:89
    old "Renderer"
    new "Renderizador"

    # renpy/common/00gltest.rpy:91
    old "Automatically Choose"
    new "Elegir automáticamente"

    # renpy/common/00gltest.rpy:96
    old "Force GL2 Renderer"
    new "Forzar renderizador GL2"

    # renpy/common/00gltest.rpy:101
    old "Force ANGLE2 Renderer"
    new "Forzar renderizador ANGLE2"

    # renpy/common/00gltest.rpy:106
    old "Force GLES2 Renderer"
    new "Forzar renderizador GLES2"

    # renpy/common/00gltest.rpy:112
    old "Enable (No Blocklist)"
    new "Activar (sin lista de bloqueo)"

    # renpy/common/00gltest.rpy:135
    old "Powersave"
    new "Ahorro de energía"

    # renpy/common/00gltest.rpy:145
    old "Framerate"
    new "Frecuencia de fotogramas"

    # renpy/common/00gltest.rpy:147
    old "Screen"
    new "Pantalla"

    # renpy/common/00gltest.rpy:151
    old "60"
    new "60"

    # renpy/common/00gltest.rpy:155
    old "30"
    new "30"

    # renpy/common/00gltest.rpy:159
    old "Tearing"
    new "Desgarro de imagen"

    # renpy/common/00gltest.rpy:171
    old "Changes will take effect the next time this program is run."
    new "Los cambios surtirán efecto la próxima vez que se ejecute este programa."

    # renpy/common/00gltest.rpy:178
    old "Quit"
    new "Quitar"

    # renpy/common/00gltest.rpy:207
    old "Performance Warning"
    new "Advertencia de rendimiento"

    # renpy/common/00gltest.rpy:212
    old "This computer is using software rendering."
    new "Esta computadora está utilizando renderizado por software."

    # renpy/common/00gltest.rpy:214
    old "This game requires use of GL2 that can't be initialised."
    new "Este juego requiere GL2, pero no se puede inicializar."

    # renpy/common/00gltest.rpy:216
    old "This computer has a problem displaying graphics: [problem]."
    new "Esta computadora tiene un problema al mostrar los gráficos: [problem]."

    # renpy/common/00gltest.rpy:220
    old "Its graphics drivers may be out of date or not operating correctly. This can lead to slow or incorrect graphics display."
    new "Es posible que los controladores gráficos estén desactualizados o no funcionen correctamente. Esto puede provocar una visualización lenta o incorrecta de los gráficos."

    # renpy/common/00gltest.rpy:224
    old "The {a=edit:1:log.txt}log.txt{/a} file may contain information to help you determine what is wrong with your computer."
    new "El archivo {a=edit:1:log.txt}log.txt{/a} puede contener información que te ayude a determinar qué problema tiene tu computadora."

    # renpy/common/00gltest.rpy:229
    old "More details on how to fix this can be found in the {a=[url]}documentation{/a}."
    new "Puedes encontrar más detalles sobre cómo solucionar esto en la {a=[url]}documentación{/a}."

    # renpy/common/00gltest.rpy:234
    old "Continue, Show this warning again"
    new "Continuar, mostrar esta advertencia nuevamente"

    # renpy/common/00gltest.rpy:238
    old "Continue, Don't show warning again"
    new "Continuar, no volver a mostrar esta advertencia"

    # renpy/common/00gltest.rpy:246
    old "Change render options"
    new "Cambiar opciones de renderizado"

    # renpy/common/00gamepad.rpy:33
    old "Select Gamepad to Calibrate"
    new "Seleccionar mando para calibrar"

    # renpy/common/00gamepad.rpy:36
    old "No Gamepads Available"
    new "No hay mandos disponibles"

    # renpy/common/00gamepad.rpy:56
    old "Calibrating [name] ([i]/[total])"
    new "Calibrando [name] ([i]/[total])"

    # renpy/common/00gamepad.rpy:60
    old "Press or move the '[control!s]' [kind]."
    new "Pulsa o mueve '[control!s]' [kind]."

    # renpy/common/00gamepad.rpy:70
    old "Skip (A)"
    new "Omitir (A)"

    # renpy/common/00gamepad.rpy:73
    old "Back (B)"
    new "Atrás (B)"

    # renpy/common/_errorhandling.rpym:764
    old "Open"
    new "Abrir"

    # renpy/common/_errorhandling.rpym:766
    old "Opens the traceback.txt file in a text editor."
    new "Abre el archivo traceback.txt en un editor de texto."

    # renpy/common/_errorhandling.rpym:768
    old "Copy BBCode"
    new "Copiar BBCode"

    # renpy/common/_errorhandling.rpym:770
    old "Copies the traceback.txt file to the clipboard as BBcode for forums like https://lemmasoft.renai.us/."
    new "Copia el archivo traceback.txt al portapapeles como BBCode para foros como https://lemmasoft.renai.us/."

    # renpy/common/_errorhandling.rpym:772
    old "Copy Markdown"
    new "Copiar Markdown"

    # renpy/common/_errorhandling.rpym:774
    old "Copies the traceback.txt file to the clipboard as Markdown for Discord."
    new "Copia el archivo traceback.txt al portapapeles como Markdown para Discord."

    # renpy/common/_errorhandling.rpym:806
    old "An exception has occurred."
    new "Se ha producido una excepción."

    # renpy/common/_errorhandling.rpym:835
    old "Rollback"
    new "Retroceder"

    # renpy/common/_errorhandling.rpym:837
    old "Attempts a roll back to a prior time, allowing you to save or choose a different choice."
    new "Intenta retroceder a un momento anterior, lo que te permite guardar o elegir una opción diferente."

    # renpy/common/_errorhandling.rpym:840
    old "Ignore"
    new "Ignorar"

    # renpy/common/_errorhandling.rpym:844
    old "Ignores the exception, allowing you to continue."
    new "Ignora la excepción, lo que te permite continuar."

    # renpy/common/_errorhandling.rpym:846
    old "Ignores the exception, allowing you to continue. This often leads to additional errors."
    new "Ignora la excepción, lo que te permite continuar. Esto suele provocar errores adicionales."

    # renpy/common/_errorhandling.rpym:850
    old "Reload"
    new "Recargar"

    # renpy/common/_errorhandling.rpym:852
    old "Reloads the game from disk, saving and restoring game state if possible."
    new "Recarga el juego desde el disco, guardando y restaurando el estado del juego si es posible."

    # renpy/common/_errorhandling.rpym:855
    old "Console"
    new "Consola"

    # renpy/common/_errorhandling.rpym:857
    old "Opens a console to allow debugging the problem."
    new "Abre una consola para permitir depurar el problema."

    # renpy/common/_errorhandling.rpym:870
    old "Quits the game."
    new "Sale del juego."

    # renpy/common/_errorhandling.rpym:892
    old "Parsing the script failed."
    new "No se pudo analizar el script."

