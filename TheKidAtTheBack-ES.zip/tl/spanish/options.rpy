﻿# TODO: Translation updated at 2026-09-27 20:49

translate spanish strings:

    # game/options.rpy:17
    old "The Kid at the Back v2.3.3"
    new "The Kid at the Back v2.3.3"

