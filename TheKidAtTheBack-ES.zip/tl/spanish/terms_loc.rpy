# TODO: Translation updated at 2026-09-27 20:49

translate spanish strings:

    # game/terms_loc.rpy:14
    old "Terms and Locations"
    new "Términos y ubicaciones"

    # game/terms_loc.rpy:440
    old "NPCs"
    new "NPCs"

    # game/terms_loc.rpy:447
    old "Faceless characters encountered."
    new "Personajes sin rostro encontrados."

    # game/terms_loc.rpy:467
    old "Places you've been in."
    new "Lugares en los que has estado."

    # game/terms_loc.rpy:487
    old "Words to Remember"
    new "Palabras que recordar"

