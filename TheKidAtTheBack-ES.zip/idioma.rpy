default letra = "e"
default arti = "le"
default arti_2 = "une"

init python:

    def actualizar_genero():

        global letra, arti, arti_2

        genero = getattr(store, "terms", "custom")

        # Si el juego usa los pronombres para determinar el género.
        if genero == "custom":
            pronombre = getattr(store, "pronoun", "")

            if pronombre == "she/her":
                genero = "feminine"

            elif pronombre == "he/him":
                genero = "masculine"

            else:
                genero = "neutral"

        if genero == "feminine":
            letra = "a"
            arti = "la"
            arti_2 = "una"

        elif genero == "masculine":
            letra = "o"
            arti = "el"
            arti_2 = "un"

        else:
            letra = "e"
            arti = "le"
            arti_2 = "une"


    def actualizar_genero_callback():
        actualizar_genero()


    config.start_interact_callbacks.append(actualizar_genero_callback)


init 1000 python:
    renpy.game.preferences.language = "spanish"


label before_main_menu:
    $ actualizar_genero()
    return    

label after_load:
    $ actualizar_genero()
    return