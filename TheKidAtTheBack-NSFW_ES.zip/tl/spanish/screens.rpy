
# TODO: Translation updated at 2026-09-25 20:21

translate spanish strings:

    # game/screens.rpy:426
    old "End Replay"
    new "Finalizar repetición"

    # game/screens.rpy:689
    old "About"
    new "Acerca de"

    # game/screens.rpy:696
    old "Version [config.version!t]\n"
    new "Versión [config.version!t]\n"

    # game/screens.rpy:702
    old "Made with {a=https://www.renpy.org/}Ren'Py{/a} [renpy.version_only].\n\n[renpy.license!t]"
    new "Hecho con {a=https://www.renpy.org/}Ren'Py{/a} [renpy.version_only].\n\n[renpy.license!t]"

    # game/screens.rpy:708
    old "The Kid at the Back made by fantasia_kitt"
    new "The Kid at the Back, creado por fantasia_kitt"

    # game/screens.rpy:713
    old "SUPPORT FANTASIA_KITT"
    new "APOYA A FANTASIA_KITT"

    # game/screens.rpy:714
    old "{a=https://x.com/fantasia_kitt}Twitter/X{/a}|{a=https://www.tumblr.com/blog/fantasia-kitt}Tumblr{/a}|{a=https://www.patreon.com/fantasia_tealcatart}Patreon{/a}"
    new "{a=https://x.com/fantasia_kitt}Twitter/X{/a}|{a=https://www.tumblr.com/blog/fantasia-kitt}Tumblr{/a}|{a=https://www.patreon.com/fantasia_tealcatart}Patreon{/a}"

    # game/screens.rpy:741
    old "CONTENT WARNINGS"
    new "ADVERTENCIAS DE CONTENIDO"

    # game/screens.rpy:759
    old "NSFW BUILD"
    new "VERSIÓN NSFW"

    # game/screens.rpy:765
    old "* Screen Shaking & Motion"
    new "* Temblor y movimiento de pantalla"

    # game/screens.rpy:766
    old "* Graphic Violence (Blood | Gore | Amputation | Beheadings)"
    new "* Violencia gráfica (sangre | vísceras | amputaciones | decapitaciones)"

    # game/screens.rpy:767
    old "* Major Character Death"
    new "* Muerte de un personaje principal"

    # game/screens.rpy:768
    old "* Player Character Death"
    new "* Muerte del personaje del jugador"

    # game/screens.rpy:769
    old "* Usage of Weapons (Guns and Pistols | Sharp Objects and Knives)"
    new "* Uso de armas (armas de fuego y pistolas | objetos afilados y cuchillos)"

    # game/screens.rpy:770
    old "* Drugging"
    new "* Administración de drogas"

    # game/screens.rpy:771
    old "* Somnophilia"
    new "* Somnofilia"

    # game/screens.rpy:772
    old "* Non-Consensual Sex (Mild to High)"
    new "* Sexo no consensuado (leve a grave)"

    # game/screens.rpy:773
    old "* Implied Child Neglect and Abuse"
    new "* Abandono y abuso infantil implícitos"

    # game/screens.rpy:774
    old "* Public Sex"
    new "* Sexo público"

    # game/screens.rpy:775
    old "* Public and Private Masturbation"
    new "* Masturbación pública y privada"

    # game/screens.rpy:776
    old " If you are uncomfortable with the warnings listed above then please {color=#ff0000}exit the game{/color}."
    new " Si las advertencias anteriores te incomodan, por favor {color=#ff0000}sal del juego{/color}."

    # game/screens.rpy:777
    old "See full content warnings through this {a=https://tkatbwarnings.carrd.co}link{/a}"
    new "Consulta las advertencias de contenido completas en este {a=https://tkatbwarnings.carrd.co}enlace{/a}"

    # game/screens.rpy:788
    old "DISCLAIMERS"
    new "DESCARGOS DE RESPONSABILIDAD"

    # game/screens.rpy:794
    old "This game is still in its development stage so there might be potential errors both grammar and code wise. If you encoutner any grammar errors and/or bugs, please do send it through this {a=https://forms.gle/LUNEKtQ5wG3HRHU39}link{/a}."
    new "Este juego todavía está en desarrollo, por lo que podría contener errores gramaticales y de código. Si encuentras algún error gramatical o fallo, envíalo a través de este {a=https://forms.gle/LUNEKtQ5wG3HRHU39}enlace{/a}."

    # game/screens.rpy:795
    old "If you have questions you would like to ask me, the creator, please do send me an {a=https://fantasiakitt.carrd.co/#contact}e-mail{/a}.\n"
    new "Si tienes alguna pregunta que quieras hacerme como creador, puedes enviarme un {a=https://fantasiakitt.carrd.co/#contact}correo electrónico{/a}.\n"

    # game/screens.rpy:796
    old "Minors are strictly prohibited from playing this game or engaging in any shape of form of the game. This game is a work of fiction, anything in this game is fiction and not based off on any real life events. Discretion is Advised\n"
    new "Los menores tienen estrictamente prohibido jugar este juego o participar en él de cualquier forma. Este juego es una obra de ficción; todo lo que aparece en él es ficticio y no está basado en ningún acontecimiento de la vida real. Se recomienda discreción.\n"

    # game/screens.rpy:797
    old "In no way, shape or form, the creator condones or accepts the illegal and horrible actions shown in-game made \nby the characters. This visual novel is made for creative venture and is pure fiction and should not be romanticize or \nreplicated in real life. \n\nIf anything comes harm to you in real life, please call your {a=https://www.dt.com/ca/wp-content/uploads/2017/03/Global-_911_Emergency-Contacts.pdf}local emergency hotline{/a}. Stay safe!"
    new "De ninguna manera el creador aprueba o respalda las acciones ilegales y horribles que realizan los personajes en el juego. Esta novela visual fue creada con fines creativos y es completamente ficticia; no debe romantizarse ni replicarse en la vida real. \n\nSi algo de esto te causa daño en la vida real, llama a tu {a=https://www.dt.com/ca/wp-content/uploads/2017/03/Global-_911_Emergency-Contacts.pdf}línea de emergencia local{/a}. ¡Mantente a salvo!"

    # game/screens.rpy:867
    old "Save"
    new "Guardar"

    # game/screens.rpy:874
    old "Load"
    new "Cargar"

    # game/screens.rpy:879
    old "| Page {} |"
    new "| Página {} |"

    # game/screens.rpy:879
    old "Automatic saves"
    new "Guardados automáticos"

    # game/screens.rpy:879
    old "Quick saves"
    new "Guardados rápidos"

    # game/screens.rpy:923
    old "{#file_time}%A, %B %d %Y, %H:%M"
    new "{#file_time}%A, %d de %B de %Y, %H:%M"

    # game/screens.rpy:923
    old "empty slot"
    new "ranura vacía"

    # game/screens.rpy:943
    old "Previous"
    new "Anterior"

    # game/screens.rpy:946
    old "{#auto_page}A"
    new "{#auto_page}A"

    # game/screens.rpy:949
    old "{#quick_page}Q"
    new "{#quick_page}R"

    # game/screens.rpy:955
    old "Next"
    new "Siguiente"

    # game/screens.rpy:1008
    old "Preferences"
    new "Preferencias"

    # game/screens.rpy:1019
    old "Display"
    new "Pantalla"

    # game/screens.rpy:1022
    old "Window"
    new "Ventana"

    # game/screens.rpy:1023
    old "Fullscreen"
    new "Pantalla completa"

    # game/screens.rpy:1027
    old "Skip"
    new "Saltar"

    # game/screens.rpy:1031
    old "Unseen Text"
    new "Texto no visto"

    # game/screens.rpy:1032
    old "After Choices"
    new "Después de las elecciones"

    # game/screens.rpy:1033
    old "Transitions"
    new "Transiciones"

    # game/screens.rpy:1043
    old "NSFW Scenes"
    new "Escenas NSFW"

    # game/screens.rpy:1047
    old "On"
    new "Sí"

    # game/screens.rpy:1048
    old "Off"
    new "No"

    # game/screens.rpy:1058
    old "Text Speed"
    new "Velocidad del texto"

    # game/screens.rpy:1062
    old "Auto-Forward Time"
    new "Tiempo de avance automático"

    # game/screens.rpy:1069
    old "Music Volume"
    new "Volumen de la música"

    # game/screens.rpy:1076
    old "Sound Volume"
    new "Volumen de los efectos de sonido"

    # game/screens.rpy:1082
    old "Test"
    new "Prueba"

    # game/screens.rpy:1086
    old "Voice Volume"
    new "Volumen de voz"

    # game/screens.rpy:1097
    old "Mute All"
    new "Silenciar todo"

    # game/screens.rpy:1223
    old "History"
    new "Historial"

    # game/screens.rpy:1253
    old "The dialogue history is empty."
    new "El historial de diálogos está vacío."

    # game/screens.rpy:1320
    old "Help"
    new "Ayuda"

    # game/screens.rpy:1329
    old "Keyboard"
    new "Teclado"

    # game/screens.rpy:1330
    old "Mouse"
    new "Ratón"

    # game/screens.rpy:1333
    old "Gamepad"
    new "Mando"

    # game/screens.rpy:1346
    old "Enter"
    new "Enter"

    # game/screens.rpy:1347
    old "Advances dialogue and activates the interface."
    new "Avanza el diálogo y activa la interfaz."

    # game/screens.rpy:1350
    old "Space"
    new "Espacio"

    # game/screens.rpy:1351
    old "Advances dialogue without selecting choices."
    new "Avanza el diálogo sin seleccionar opciones."

    # game/screens.rpy:1354
    old "Arrow Keys"
    new "Teclas de flecha"

    # game/screens.rpy:1355
    old "Navigate the interface."
    new "Navega por la interfaz."

    # game/screens.rpy:1358
    old "Escape"
    new "Escape"

    # game/screens.rpy:1359
    old "Accesses the game menu."
    new "Accede al menú del juego."

    # game/screens.rpy:1362
    old "Ctrl"
    new "Ctrl"

    # game/screens.rpy:1363
    old "Skips dialogue while held down."
    new "Salta el diálogo mientras se mantiene presionada."

    # game/screens.rpy:1366
    old "Tab"
    new "Tab"

    # game/screens.rpy:1367
    old "Toggles dialogue skipping."
    new "Activa o desactiva el salto de diálogos."

    # game/screens.rpy:1370
    old "Page Up"
    new "Re Pág"

    # game/screens.rpy:1371
    old "Rolls back to earlier dialogue."
    new "Retrocede a diálogos anteriores."

    # game/screens.rpy:1374
    old "Page Down"
    new "Av Pág"

    # game/screens.rpy:1375
    old "Rolls forward to later dialogue."
    new "Avanza a diálogos posteriores."

    # game/screens.rpy:1379
    old "Hides the user interface."
    new "Oculta la interfaz de usuario."

    # game/screens.rpy:1383
    old "Takes a screenshot."
    new "Toma una captura de pantalla."

    # game/screens.rpy:1387
    old "Toggles assistive {a=https://www.renpy.org/l/voicing}self-voicing{/a}."
    new "Activa o desactiva la {a=https://www.renpy.org/l/voicing}lectura automática{/a}."

    # game/screens.rpy:1391
    old "Opens the accessibility menu."
    new "Abre el menú de accesibilidad."

    # game/screens.rpy:1397
    old "Left Click"
    new "Clic izquierdo"

    # game/screens.rpy:1401
    old "Middle Click"
    new "Clic central"

    # game/screens.rpy:1405
    old "Right Click"
    new "Clic derecho"

    # game/screens.rpy:1409
    old "Mouse Wheel Up\nClick Rollback Side"
    new "Rueda del ratón hacia arriba\nClic en el lado de retroceso"

    # game/screens.rpy:1413
    old "Mouse Wheel Down"
    new "Rueda del ratón hacia abajo"

    # game/screens.rpy:1420
    old "Right Trigger\nA/Bottom Button"
    new "Gatillo derecho\nA/Botón inferior"

    # game/screens.rpy:1424
    old "Left Trigger\nLeft Shoulder"
    new "Gatillo izquierdo\nBotón superior izquierdo"

    # game/screens.rpy:1428
    old "Right Shoulder"
    new "Botón superior derecho"

    # game/screens.rpy:1433
    old "D-Pad, Sticks"
    new "Cruceta, palancas"

    # game/screens.rpy:1437
    old "Start, Guide"
    new "Start, Guide"

    # game/screens.rpy:1441
    old "Y/Top Button"
    new "Y/Botón superior"

    # game/screens.rpy:1444
    old "Calibrate"
    new "Calibrar"

    # game/screens.rpy:1509
    old "Yes"
    new "Sí"

    # game/screens.rpy:1510
    old "No"
    new "No"

    # game/screens.rpy:1562
    old "Skipping"
    new "Saltando"
    
    old "Content Warnings" 
    new "Advertencias"
    
    old "Preference"
    new "Preferencias"
    
    old "Start"
    new "Iniciar"
    
    old "RETURN"
    new "VOLVER"
    
    old "Main Menu" 
    new "Menu principal"
        
    old "Red-Haired Bully" 
    new "Bully Pelirrojo"
    
    old "Blonde Bully" 
    new "Bully Rubio"
    
    old "Ravenette Bully" 
    new "Bully Moreno"
    
    old "Nurse" 
    new "Enfermera"
    
    old "Professor" 
    new "Profesor"
    
    old "Raven-Haired Bully" 
    new "Bully Moreno"
    
    old "Librarian" 
    new "Bibliotecario"
    
    old "Barista" 
    new "Barista"
    
    old "Rough Voice" 
    new "Voz Grave"
    
    old "Meek Voice" 
    new "Voz Suave"
    
    old "Young Man" 
    new "Joven"
    
    old "Tall Young man" 
    new "Joven Alto"
    
    old "Reporter" 
    new "Reportero"
    
    old "Oogami Member" 
    new "Miembro Oogami"
    
    old "Father" 
    new "Padre"
    
    old "Student" 
    new "Estudiante"
    
    old "Mr. Z" 
    new "Sr. Z"

    old "{color=#f00}{b}WARNING + DISCLAIMER{/b}{/color}\n \n{i}This game is rated 18+{/i} \n Minors are strictly prohibited from playing this game or engaging in any shape of form of the game.{i}\n This game is a work of fiction, anything in this game is fiction and not based off on any real life events \n Discretion is Advised.{/i}" 
    new "{color=#f00}{b}ADVERTENCIA + AVISO{/b}{/color}\n \n{i}Este juego es para mayores de 18 años{/i} \n Los menores tienen estrictamente prohibido jugar este juego o participar de cualquier forma en él.{i}\n Este juego es una obra de ficción, todo en este juego es ficción y no se basa en hechos de la vida real \n Se recomienda discreción.{/i}"

    old "You"
    new "Tu"