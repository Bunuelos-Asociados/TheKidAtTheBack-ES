﻿
# TODO: Translation updated at 2026-09-25 20:21

translate spanish strings:

    # game/entries.rpy:16
    old "NPCS"
    new "NPCS"

    # game/entries.rpy:33
    old "BULLIES\n"
    new "MATONES\n"

    # game/entries.rpy:39
    old "Despite their age and supposed to be \"maturity\", their egos are as high as the skies. Formerly High Class students, these bullies dread being looked down upon especially by people who they deem lower than them. They torment any poor soul and the sad reality is that they can get away with things due to their high background. {p}"
    new "A pesar de su edad y su supuesta \"madurez\", tienen el ego por las nubes. Antiguamente estudiantes de Clase Alta, estos matones detestan que los menosprecien, especialmente las personas a las que consideran inferiores a ellos. Atormentan a cualquier pobre alma que se cruce en su camino y, por desgracia, pueden salirse con la suya debido a su posición privilegiada. {p}"

    # game/entries.rpy:42
    old "Most of them torment for the sake of tormenting, anything to make them feel superior while some do it out of pure hatred and jealousy. Once 'kind' students brought down to ruthless people, from simple punches to ruining one's reputation. {p}"
    new "La mayoría atormenta a los demás por el simple placer de hacerlo, cualquier cosa que los haga sentirse superiores, mientras que algunos lo hacen por puro odio y celos. Estudiantes que alguna vez fueron 'amables' y que terminaron convirtiéndose en personas despiadadas, desde simples golpes hasta arruinar la reputación de alguien. {p}"

    # game/entries.rpy:76
    old "FACULTY\n"
    new "PERSONAL DOCENTE\n"

    # game/entries.rpy:82
    old "Teachers and the school's head all alike. They're the school's higher-ups who keep the school in check and are the ones responsible for teaching the students in Olympeius University. There are rumors circulating that some teachers don't do their job well by not attending several classes or not teaching at all. One of the few known reasons is their wage being low and insufficient to meet their needs. These rumors are often debunked by the Head. . {p}"
    new "Los profesores y la dirección de la escuela. Son los superiores encargados de mantener la institución bajo control y de enseñar a los estudiantes de Olympeius University. Circulan rumores de que algunos profesores no hacen bien su trabajo, ya sea porque faltan a varias clases o porque directamente no enseñan. Una de las pocas razones conocidas es que sus salarios son bajos e insuficientes para cubrir sus necesidades. La dirección suele desmentir estos rumores. . {p}"

    # game/entries.rpy:86
    old "While some you may come to hate, there are also whom you cannot stay mad at. {p}"
    new "Aunque puede que llegues a odiar a algunos, también hay quienes hacen imposible que te mantengas enojado con ellos. {p}"

    # game/entries.rpy:120
    old "THE MOB\n"
    new "LA MAFIA\n"

    # game/entries.rpy:126
    old "A group of Higher Class people, all well dressed but ill-mannered. In the day time, they're nothing but normal citizens save for their intimdating looks and often coming in groups. During the night however, you coul donly imagine what they're up to, you have to stay vigilant around people like them. {p}"
    new "Un grupo de personas de Clase Alta, todas bien vestidas pero maleducadas. Durante el día no son más que ciudadanos comunes, salvo por su apariencia intimidante y por el hecho de que suelen andar en grupos. Sin embargo, durante la noche, solo puedes imaginar lo que hacen. Tienes que mantenerte alerta cuando estés cerca de gente como ellos. {p}"

    # game/entries.rpy:158
    old "Mr. Z\n"
    new "Sr. Z\n"

    # game/entries.rpy:164
    old "The man that came to take your land. He considers himself a 'nice guy', a title that contradicst his crooked methods of handling situations and people.{p}You have no idea why he is willing to shoulder your expenses but one thing's for sure, it's either your land or your head. {p}"
    new "El hombre que vino a quedarse con tus tierras. Se considera un 'buen tipo', un título que contradice sus retorcidos métodos para tratar con las situaciones y las personas.{p}No tienes idea de por qué está dispuesto a hacerse cargo de tus gastos, pero una cosa es segura: o se queda con tus tierras o con tu cabeza. {p}"

    # game/entries.rpy:196
    old "ERIES"
    new "ERIES"

    # game/entries.rpy:202
    old "\"Titus City's top one idol, model, and actor. This man is the serial killer's actor in the movie you and Crowe watched. {p}He is Jess' favorite actor and is the one of the most famous idols within the city.{p}{p}He has a large fanbase with the biggest group owned by Jess and because of her dedication towards him, she received his recognition in one interview.{p}Your type or not, you've got to admit he's got the face of an angel."
    new "\"El principal ídolo, modelo y actor de Titus City. Este hombre interpreta al asesino en serie en la película que tú y Crowe vieron. {p}Es el actor favorito de Jess y uno de los ídolos más famosos de la ciudad.{p}{p}Cuenta con una enorme base de fans, cuyo grupo más grande es administrado por Jess. Gracias a su dedicación hacia él, recibió un reconocimiento suyo durante una entrevista.{p}Sea o no tu tipo, tienes que admitir que tiene el rostro de un ángel."

    # game/entries.rpy:216
    old "LOCATIONS"
    new "LUGARES"

    # game/entries.rpy:236
    old "Titus City"
    new "Titus City"

    # game/entries.rpy:242
    old "{p}The Largest City of the land, located at the very middle of the country. Surroundingit are bbenefical regions: the cold North, the warm South, the prosperic West and the cultural East. {p}{p}Titus City is said to be the land where Gods and Mortals co-exsist, they advertise this metaphor, for idols and actors live within Titus City and are often treated like deities. Littered with large buildings, colorful city lights and bustling businesses, all your dreams can come true if you come to Titus City. {p}"
    new "{p}La ciudad más grande del país, ubicada justo en el centro. La rodean regiones de gran importancia: el frío Norte, el cálido Sur, el próspero Oeste y el cultural Este. {p}{p}Se dice que Titus City es la tierra donde dioses y mortales coexisten. Esta metáfora se utiliza debido a que los ídolos y actores viven en Titus City y a menudo son tratados como deidades. Repleta de grandes edificios, luces urbanas de colores y negocios llenos de actividad, todos tus sueños pueden hacerse realidad si vienes a Titus City. {p}"

    # game/entries.rpy:273
    old "Olympeius University"
    new "Olympeius University"

    # game/entries.rpy:279
    old "{p}Titus City's largest University is known for raising outstanding students who achieve the highest levels of success. Students that come from this school largely help the city prosper and attain the economy it has today.{p}Despite its great reputation on the outside, a dark secret lies within the building that no one dares to talk ill about, unless they want either their family or lives at stake."
    new "{p}La universidad más grande de Titus City es conocida por formar estudiantes sobresalientes que alcanzan los niveles más altos de éxito. Los estudiantes que salen de esta institución contribuyen en gran medida a la prosperidad de la ciudad y a la economía que tiene actualmente.{p}A pesar de su excelente reputación de puertas para afuera, dentro del edificio se esconde un oscuro secreto del que nadie se atreve a hablar mal, a menos que quiera poner en riesgo a su familia o su propia vida."

    # game/entries.rpy:308
    old "South Region"
    new "Región Sur"

    # game/entries.rpy:314
    old "{p}The South is where Beautiful fields of grass are found in the South, where farmers cultivate their land as the sole providers of food and quality crops that help Titus City prosper. {p}While the South doesn't have a large-scale modernized landscape, their land is the only place where natural crops can grow well and accordingly, business owners in Titus City would often move to the South or strike deals with farmers."
    new "{p}En el Sur se encuentran hermosos campos de hierba, donde los agricultores cultivan sus tierras y son los principales proveedores de alimentos y cosechas de calidad que ayudan a Titus City a prosperar. {p}Aunque el Sur no cuenta con un paisaje modernizado a gran escala, sus tierras son el único lugar donde los cultivos naturales pueden crecer adecuadamente. Por ello, los empresarios de Titus City suelen mudarse al Sur o hacer acuerdos con los agricultores."

    # game/entries.rpy:343
    old "North Region"
    new "Región Norte"

    # game/entries.rpy:349
    old "{p}While the South is filled with beautiful grasslands and animals, the North is littered with white and cold. Despite all of that, they have beautiful mountains and exotic animals, making it an amazing tourist spot especially to the people in the city. {p} However, cars as a mode of transportation is not viable, thus the new railway train managed by the Asmodias corp helped traveling from Titus City to the North ten times easier."
    new "{p}Mientras que el Sur está lleno de hermosas praderas y animales, el Norte está cubierto de blanco y frío. A pesar de ello, cuenta con hermosas montañas y animales exóticos, lo que lo convierte en un increíble destino turístico, especialmente para la gente de la ciudad. {p}Sin embargo, los automóviles no son un medio de transporte viable, por lo que el nuevo tren ferroviario administrado por Asmodias corp facilitó diez veces los viajes desde Titus City hasta el Norte."

    # game/entries.rpy:378
    old "Your Apartment"
    new "Tu apartamento"

    # game/entries.rpy:384
    old "{p}Handpicked by Mr. Z himself, your apartment is on the second floor of a building located near the park and not too far from your school. You walk home on sunny days and commute if it rains. {p}{p}The place however, does not allow pets inside due to past complaints. Despite that, the place is surprisngly comfortable, though the occasional broken window in your room pisses you off and your landlord will probably have your neck if he finds out you broke something within the apartment. "
    new "{p}Elegido personalmente por el Sr. Z, tu apartamento está en el segundo piso de un edificio ubicado cerca del parque y no demasiado lejos de tu escuela. Caminas a casa en los días soleados y usas el transporte público cuando llueve. {p}{p}Sin embargo, no se permiten mascotas dentro debido a quejas anteriores. A pesar de eso, el lugar es sorprendentemente cómodo, aunque la ventana rota ocasionalmente en tu habitación te saca de quicio, y probablemente tu casero te hará pagar caro si descubre que rompiste algo dentro del apartamento. "

    # game/entries.rpy:412
    old "School Garden"
    new "Jardín de la escuela"

    # game/entries.rpy:418
    old "{p}Throughout the years, the school garden has become your safe haven. You take pride in tending to the crops and flowers within the greenhouse— an activity you are highly familiar with as it resembles the life you had at home. The garden also provides the perfect picnic spot whenever you have a shift here."
    new "{p}Con el paso de los años, el jardín de la escuela se ha convertido en tu refugio. Te enorgullece cuidar los cultivos y las flores del invernadero, una actividad con la que estás muy familiarizado, ya que se parece a la vida que llevabas en casa. El jardín también es el lugar perfecto para hacer un picnic cada vez que tienes un turno aquí."

    # game/entries.rpy:447
    old "Lilith's Tree"
    new "Árbol de Lilith"

    # game/entries.rpy:453
    old "{p}A tall old tree hidden within the multiple shrubs of the park that Crowe found. It is said that the tree once bore fruit to healing factors, cultivated by the gods but never for human consumption. There are multiple variations of the tree’s story, from hopeful to straight up horror stories."
    new "{p}Un viejo árbol de gran altura oculto entre los numerosos arbustos del parque que Crowe encontró. Se dice que el árbol alguna vez dio frutos con propiedades curativas, cultivados por los dioses, pero nunca destinados al consumo humano. Existen múltiples versiones de la historia del árbol, desde relatos esperanzadores hasta auténticas historias de terror."

    # game/entries.rpy:469
    old "TERMS"
    new "TÉRMINOS"

    # game/entries.rpy:486
    old "The Hierarchy"
    new "La Jerarquía"

    # game/entries.rpy:492
    old "{p}A hidden system that allows people in power to attain more success while those who have nothing leave with nothing. The Hierarchy separates people into two different categories: the High Class and the Low Class.{p} This unspoken rule is placed upon the citizens of Titus City and is highly practiced within Olympeius University. Protests against the system have occurred but many have failed and lost. Fearing for the worst, Low Class citizens can only fight to join the higher ranks... or die trying. "
    new "{p}Un sistema oculto que permite a las personas con poder alcanzar aún más éxito, mientras que quienes no tienen nada se quedan sin nada. La Jerarquía divide a las personas en dos categorías diferentes: la Clase Alta y la Clase Baja.{p}Esta regla no escrita se impone a los ciudadanos de Titus City y se practica ampliamente dentro de Olympeius University. Se han producido protestas contra el sistema, pero muchas han fracasado y terminado en derrota. Temiendo lo peor, los ciudadanos de Clase Baja solo pueden luchar para ascender a los rangos superiores... o morir en el intento. "

    # game/entries.rpy:521
    old "The High Class"
    new "La Clase Alta"

    # game/entries.rpy:527
    old "{p}People who belong here are known for having fat wallets and beautiful features, as if they were crafted by the gods themselves. Despite their pleasant exterior, they are rotten and reeking with wickedness within. {p}While there are High Class citizens who do not care about The Hierarchy, most take advantage of their position to tilt things in their favor. {p}Power is what they crave, and they are not afraid to get their hands dirty to achieve what they want. "
    new "{p}Las personas que pertenecen a esta clase son conocidas por tener billeteras abultadas y rasgos hermosos, como si hubieran sido creadas por los propios dioses. A pesar de su agradable apariencia exterior, por dentro están podridas y rebosan maldad. {p}Aunque hay ciudadanos de Clase Alta a quienes no les importa la Jerarquía, la mayoría se aprovecha de su posición para inclinar las cosas a su favor. {p}Lo que ansían es poder, y no tienen miedo de ensuciarse las manos para conseguir lo que quieren. "

    # game/entries.rpy:556
    old "The Low Class"
    new "La Clase Baja"

    # game/entries.rpy:562
    old "{p}Low Class citizens often come from outside the city or are former High Class people who have fallen rank due to their bad reputation, a failed class at the University, or both.{p}They are usually motivated or desperate to build themselves up and reach the level of the High Class, to provide, to prove themselves, and to be part of the living. "
    new "{p}Los ciudadanos de Clase Baja suelen venir de fuera de la ciudad o ser antiguos miembros de la Clase Alta que han descendido de rango debido a su mala reputación, haber reprobado una asignatura en la universidad o ambas cosas.{p}Por lo general, están motivados o desesperados por salir adelante y alcanzar el nivel de la Clase Alta, para poder mantenerse, demostrar su valor y formar parte de los que viven con privilegios. "

    # game/entries.rpy:591
    old "The Hallow's Ball"
    new "El Baile de Halloween"

    # game/entries.rpy:597
    old "{p} The ppcoming Olympeius University's Halloween Party! You're very much interested attending, seeing that you have never been to a ball much less a party.{p}{p}Having to enjoy yourself on a halloween night might not be so bad. Now all you need to do is to plan out your costume! But wait, what are you going to be....?"
    new "{p}¡La próxima fiesta de Halloween de Olympeius University! Te interesa mucho asistir, ya que nunca has estado en un baile, mucho menos en una fiesta.{p}{p}Quizá no estaría tan mal divertirte durante una noche de Halloween. ¡Ahora todo lo que necesitas hacer es planear tu disfraz! Pero espera, ¿de qué vas a disfrazarte....?"

    # game/entries.rpy:626
    old "Religion"
    new "Religión"

    # game/entries.rpy:632
    old "{p} People believe in multiple gods and each location worships a patron saint. Southern inhabitants pray to the Goddess of Harvest while the North reveres the God of the Skies.{p} Since Titus City has a large and growing population, churches and shrines of individual Gods are built throughout the country, most often located near their respective regions. For instance, right around the South border lies a small church for the Goddess of Harvest."
    new "{p}Las personas creen en múltiples dioses y cada región venera a un santo patrono. Los habitantes del Sur rezan a la Diosa de la Cosecha, mientras que en el Norte veneran al Dios de los Cielos.{p}Debido a que Titus City tiene una población grande y en crecimiento, se construyen iglesias y santuarios dedicados a dioses individuales por todo el país, generalmente cerca de sus respectivas regiones. Por ejemplo, justo en la frontera sur se encuentra una pequeña iglesia dedicada a la Diosa de la Cosecha."

    # game/entries.rpy:661
    old "Your Debt"
    new "Tu deuda"

    # game/entries.rpy:667
    old "{p} You were kept in the dark about your family debt for who knows how long. You have no idea when this started or when it festered, much less how this was kept hidden by your father. One thing's for sure, your home is at stake and you are now faced with the decision to sacrifice your land, your life, or the only family you have left."
    new "{p}Te mantuvieron en la oscuridad sobre la deuda de tu familia durante quién sabe cuánto tiempo. No tienes idea de cuándo comenzó ni de cuándo se agravó, y mucho menos de cómo tu padre logró mantenerla oculta. Una cosa es segura: tu hogar está en juego y ahora debes decidir si sacrificas tus tierras, tu vida o a la única familia que te queda."
