# TODO: Translation updated at 2026-09-25 20:21

# game/script.rpy:48
translate spanish overhere_a12a8258:

    # "Welcome to The Kid at the Back"
    "Bienvenido a The Kid at the Back"

# game/script.rpy:59
translate spanish overhere_2fded262:

    # h "..."
    h "..."

# game/script.rpy:60
translate spanish overhere_72ebb54f:

    # h "Have you ever heard of the saying: {i}Curiosity kills the cat?{/i}"
    h "¿Alguna vez has oído el dicho: {i}La curiosidad mata al gato?{/i}"

# game/script.rpy:61
translate spanish overhere_36183ee8:

    # h "You've made your choice."
    h "Has hecho tu elección."

# game/script.rpy:62
translate spanish overhere_452e3f50:

    # h "{b}Leave."
    h "{b}Salir."

# game/script.rpy:66
translate spanish overhere_1d508107:

    # "If you're over 18 and clicked that button on accident, you can shoot an email to the developer at {a=https://fantasiakitt.carrd.co/#contact}the website{/a}."
    "Si tienes más de 18 años y hiciste clic en ese botón por accidente, puedes enviar un correo al desarrollador en {a=https://fantasiakitt.carrd.co/#contact}el sitio web{/a}."

translate spanish strings:

    # game/script.rpy:116
    old "A game by fantasia_kitt presents..."
    new "Un juego de fantasia_kitt presenta..."

    # game/script.rpy:118
    old "The Kid at the Back"
    new "The Kid at the Back"

    # game/script.rpy:120
    old "DISCLAIMER"
    new "ADVERTENCIA"

    # game/script.rpy:122
    old "The Kid at the Back is a thriller/horror Visual Novel with romantic elements but it is not to be treated like a regular romance novel. Minors are strictly prohibited from playing this game or engaging in any shape of form of the game. The creator does not condone or accepts the illegal and horrible actions shown in-game made by the characters in any way shape or form. \n\nThis visual novel is made for creative venture and is pure fiction and should not be romanticize or replicated in real life."
    new "The Kid at the Back es una novela visual de suspenso/terror con elementos románticos, pero no debe considerarse una novela romántica convencional. Los menores tienen estrictamente prohibido jugar este juego o participar en él de cualquier forma. El creador no aprueba ni respalda de ninguna manera las acciones ilegales y horribles que realizan los personajes en el juego. \n\nEsta novela visual fue creada con fines creativos y es completamente ficticia. No debe romantizarse ni replicarse en la vida real."

    # game/script.rpy:124
    old "This game includes explicit and dark themes such as major character death to both the characters and the player, murder, sexual assault, non-consensual touching/sex, implied abuse, bullying, usage of firearms and weapons (guns, swords, sharp weapons), drugging, violence and more. To see a more detailed list of triggers, please click this {a=https://tkatbwarnings.carrd.co}link{/a}."
    new "Este juego incluye temas explícitos y oscuros, como la muerte de personajes principales y del jugador, asesinato, agresión sexual, tocamientos/sexo no consensuados, abuso implícito, acoso, uso de armas de fuego y otras armas (pistolas, espadas, armas cortantes), administración de drogas, violencia y más. Para ver una lista más detallada de los temas sensibles, haz clic en este {a=https://tkatbwarnings.carrd.co}enlace{/a}."

    # game/script.rpy:126
    old "The Kid at the Back is intended for mature audiences only."
    new "The Kid at the Back está destinado únicamente a un público adulto."

    # game/script.rpy:128
    old "Viewer discretion is advised."
    new "Se recomienda discreción."

    # game/script.rpy:135
    old "I am over 18 and consent to play"
    new "Tengo más de 18 años"

    # game/script.rpy:136
    old "I am under 18 or do not consent"
    new "Tengo menos de 18 años"

