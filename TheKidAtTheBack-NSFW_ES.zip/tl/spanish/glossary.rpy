﻿# TODO: Translation updated at 2026-09-25 20:21

translate spanish strings:

    # game/glossary.rpy:135
    old "Solivan Brugmansia"
    new "Solivan Brugmansia"

    # game/glossary.rpy:151
    old "{size=30}{color=#0d7f00ff}Birthday:{/color}{/size}{size=25} November 1{/size}"
    new "{size=30}{color=#0d7f00ff}Cumpleaños:{/color}{/size}{size=25} 1 de noviembre{/size}"

    # game/glossary.rpy:155
    old "{size=30}{color=#0d7f00ff}Age:{/color}{/size}{size=25} 23{/size}"
    new "{size=30}{color=#0d7f00ff}Edad:{/color}{/size}{size=25} 23{/size}"

    # game/glossary.rpy:159
    old "{size=30}{color=#0d7f00ff}Height:{/color}{/size}{size=25} 190cm{/size}"
    new "{size=30}{color=#0d7f00ff}Altura:{/color}{/size}{size=25} 190 cm{/size}"

    # game/glossary.rpy:162
    old "{size=30}{color=#0d7f00ff}Likes:{/color}{/size}{size=25} poems and art, historic artifacs, spicy food, plushies, \nHorses{/size}"
    new "{size=30}{color=#0d7f00ff}Le gusta:{/color}{/size}{size=25} los poemas y el arte, artefactos históricos, comida picante, peluches, \ncaballos{/size}"

    # game/glossary.rpy:166
    old "{size=30}{color=#0d7f00ff}Dislikes:{/color}{/size}{size=25} house hires, the ocean & crabs, loud noises, \nDisruption {/size}"
    new "{size=30}{color=#0d7f00ff}No le gusta:{/color}{/size}{size=25} los incendios provocados, el océano y los cangrejos, los ruidos fuertes, \nlas interrupciones{/size}"

    # game/glossary.rpy:179
    old "The classmate you never noticed sitting at the back of the class. Solivan is not the type to show himself or make himself known, often staying behind in the darkest corners of the school and never uttering a single word. Sol is artistic and a fan of historic events and classic literature.\n {p}People find him creepy while some find him weird, but despite all of the comments made towards him, you came to get to know about his character and he turned out to be the sweetest person you've met next to Crowe. Because of that, you are determined to uncover his character and to what other secrets he is hiding within his heart. {p}And he is more than willing to let you into his life."
    new "El compañero de clase que nunca notaste sentado al fondo del salón. Solivan no es de los que se muestran o hacen notar, y suele quedarse en los rincones más oscuros de la escuela sin pronunciar una sola palabra. Sol es artístico y aficionado a los acontecimientos históricos y a la literatura clásica.\n {p}Algunos lo consideran espeluznante y otros lo encuentran extraño, pero a pesar de todos los comentarios que hacen sobre él, llegaste a conocerlo mejor y resultó ser la persona más dulce que has conocido, después de Crowe. Por eso, estás decidido a descubrir cómo es realmente y qué otros secretos oculta en su corazón. {p}Y él está más que dispuesto a dejarte entrar en su vida."

    # game/glossary.rpy:193
    old "{font=fonts/BIZUDPMinchor.ttf}{color=#000000}|"
    new "{font=fonts/BIZUDPMinchor.ttf}{color=#000000}|"

    # game/glossary.rpy:195
    old "Relationship Chart"
    new "Tabla de relaciones"

    # game/glossary.rpy:201
    old "Comments"
    new "Comentarios"

    # game/glossary.rpy:387
    old "Creator's Comments"
    new "Comentarios del creador"

    # game/glossary.rpy:405
    old "What made you make this character?\n"
    new "¿Qué te llevó a crear este personaje?\n"

    # game/glossary.rpy:409
    old "I wanted to have a 'stinky and basement dweller' yandere OC during 4 in the morning, basically I wanted to make a character that's giving boy loser vibes since half of my characters are either cheerful or supermodels.\n"
    new "Quería tener un personaje original yandere que fuera un 'apestoso que vive en un sótano' a las 4 de la mañana. Básicamente, quería crear un personaje con vibra de chico perdedor, ya que la mitad de mis personajes son alegres o supermodelos.\n"

    # game/glossary.rpy:412
    old "Where did you get their inspiration from?\n"
    new "¿De dónde sacaste la inspiración para este personaje?\n"

    # game/glossary.rpy:416
    old "Is it embarrassing to say that he's my type. I'm fond of characters like Sebastian from Stardew Valley and literally Sasuke Uchiha from Naruto, he's basically my dream guy in terms of talent, looks, height and personality (minus the yandere tendencies of course).\n"
    new "¿Es vergonzoso decir que es mi tipo? Me gustan personajes como Sebastian de Stardew Valley y, literalmente, Sasuke Uchiha de Naruto. Básicamente, es el chico de mis sueños en cuanto a talento, apariencia, altura y personalidad (dejando de lado sus tendencias yandere, claro).\n"

    # game/glossary.rpy:419
    old "Would you get along with this character in real life?\n"
    new "¿Te llevarías bien con este personaje en la vida real?\n"

    # game/glossary.rpy:423
    old "I'm an introvert in real life and he is too, I'd say it would be a 50/50, either he's going to enjoy my company or he's planning my death the next.\n"
    new "Soy una persona introvertida en la vida real y él también. Diría que sería un 50/50: o disfrutaría de mi compañía o estaría planeando mi muerte al día siguiente.\n"

    # game/glossary.rpy:426
    old "What will you say to the fans of this character?\n"
    new "¿Qué les dirías a los fans de este personaje?\n"

    # game/glossary.rpy:430
    old "I hope you all enjoy Sol as a character! There will be more to him in future updates and he's definitely one of my favorite characters and I had fun writng him!\n"
    new "¡Espero que todos disfruten de Sol como personaje! Habrá más sobre él en futuras actualizaciones. Definitivamente es uno de mis personajes favoritos y ¡me divertí mucho escribiéndolo!\n"

    # game/glossary.rpy:489
    old "Jericho Ichabod | Crowe"
    new "Jericho Ichabod | Crowe"

    # game/glossary.rpy:500
    old "{size=30}{color=#19197aff}Birthday:{/color}{/size}{size=25} Sept 14{/size}"
    new "{size=30}{color=#19197aff}Cumpleaños:{/color}{/size}{size=25} 14 de septiembre{/size}"

    # game/glossary.rpy:504
    old "{size=30}{color=#19197aff}Age:{/color}{/size}{size=25} 23{/size}"
    new "{size=30}{color=#19197aff}Edad:{/color}{/size}{size=25} 23{/size}"

    # game/glossary.rpy:508
    old "{size=30}{color=#19197aff}Height:{/color}{/size}{size=25} 185cm{/size}"
    new "{size=30}{color=#19197aff}Altura:{/color}{/size}{size=25} 185 cm{/size}"

    # game/glossary.rpy:512
    old "{size=30}{color=#19197aff}Likes:{/color}{/size}{size=25} Smell of Books, Antique jewelries, blueberry pies, \nAstrology, Night strolls{/size}"
    new "{size=30}{color=#19197aff}Le gusta:{/color}{/size}{size=25} el olor de los libros, las joyas antiguas, los pasteles de arándanos, \nla astrología, los paseos nocturnos{/size}"

    # game/glossary.rpy:516
    old "{size=30}{color=#19197aff}Dislikes:{/color}{/size}{size=25} Rainy days, Sour candy, Uncertainty{/size}"
    new "{size=30}{color=#19197aff}No le gusta:{/color}{/size}{size=25} los días lluviosos, los dulces ácidos, la incertidumbre{/size}"

    # game/glossary.rpy:530
    old "Your savior and the prince in your dreams. Jericho (Crowe) is a well-mannered man from the way he walks, from the way he dresses and carries himself. Crowe is reliable and an amazing shoulder to lean on, some would say that he's quite a charmer, with his looks and personality combined, who wouldn't want him?\n {p}But despite that, no one seemed to take notice of him as if they're scared to approach him. Crowe has been your best friend since then and has always been there to take care of you and your needs. \n {p}But why just yours? Why does he refuse to ask for your help? Would he be the type to let you shoulder his burden?"
    new "Tu salvador y el príncipe de tus sueños. Jericho (Crowe) es un hombre bien educado, desde su forma de caminar hasta su manera de vestir y comportarse. Crowe es confiable y un hombro increíble en el que apoyarse. Algunos dirían que es todo un encantador; con su apariencia y personalidad combinadas, ¿quién no lo querría?\n {p}Pero, a pesar de eso, nadie parecía fijarse en él, como si tuvieran miedo de acercarse. Crowe se convirtió en tu mejor amigo y siempre ha estado ahí para cuidar de ti y de tus necesidades. \n {p}Pero ¿por qué solo de las tuyas? ¿Por qué se niega a pedirte ayuda? ¿Sería capaz de dejarte cargar con sus problemas?"

    # game/glossary.rpy:571
    old "Crowe's thoughts towards..."
    new "Los pensamientos de Crowe sobre..."

    # game/glossary.rpy:758
    old "At first I wasn't planning on giving Sol a rival since my original plan is a very short game, but I wanted some conflict and woulnd't a rival make things spicier? Especially someone who hasn't done anything wrong in their entire life?\n"
    new "Al principio no pensaba darle un rival a Sol, ya que mi plan original era hacer un juego muy corto, pero quería algo de conflicto y ¿acaso un rival no haría las cosas más interesantes? Especialmente alguien que nunca ha hecho nada malo en toda su vida.\n"

    # game/glossary.rpy:765
    old "During his creation, I was deeply in love in Suguru Geto from JJK and Hythlodeus from FFXIV so I based off his looks from those two characters. It's made visible with his earrings and his hairstyle. I also wanted a princely character in contrast to Sol's dark and mysterious character.\n"
    new "Durante su creación, estaba profundamente enamorada de Suguru Geto de JJK y Hythlodeus de FFXIV, así que basé su apariencia en esos dos personajes. Esto se puede ver en sus pendientes y su peinado. También quería un personaje de aspecto principesco que contrastara con el carácter oscuro y misterioso de Sol.\n"

    # game/glossary.rpy:772
    old "I would owe my life to this character if he ever is real, he's a sweet and caring person and would often sacrifice his time to make time with you. He's reliable and very charming, whoever shares the same personality as Crowe and his nature, congratulations you just won the lottery.\n"
    new "Le debería la vida a este personaje si alguna vez fuera real. Es una persona dulce y atenta, y a menudo sacrificaría su tiempo para pasar tiempo contigo. Es confiable y muy encantador. Si alguien comparte la personalidad y naturaleza de Crowe, felicidades: te sacaste la lotería.\n"

    # game/glossary.rpy:779
    old "There's so much I would love to share about Crowe to my fellow fans! I had fun wiritng his backstory and I hope everyone would enjoy his character development throughout each update! Also brace yourselves, his route his pretty rocky :)\n"
    new "¡Hay tantas cosas que me encantaría compartir sobre Crowe con mis compañeros fans! Me divertí mucho escribiendo su historia y espero que todos disfruten del desarrollo de su personaje con cada actualización. Además, prepárense: su ruta será bastante complicada :)\n"

    # game/glossary.rpy:838
    old "Hyugo Sugimoto"
    new "Hyugo Sugimoto"

    # game/glossary.rpy:849
    old "{size=30}{color=#009c9cff}Birthday:{/color}{/size}{size=25} March 29{/size}"
    new "{size=30}{color=#009c9cff}Cumpleaños:{/color}{/size}{size=25} 29 de marzo{/size}"

    # game/glossary.rpy:853
    old "{size=30}{color=#009c9cff}Age:{/color}{/size}{size=25} 22{/size}"
    new "{size=30}{color=#009c9cff}Edad:{/color}{/size}{size=25} 22{/size}"

    # game/glossary.rpy:857
    old "{size=30}{color=#009c9cff}Height:{/color}{/size}{size=25} 174cm{/size}"
    new "{size=30}{color=#009c9cff}Altura:{/color}{/size}{size=25} 174 cm{/size}"

    # game/glossary.rpy:861
    old "{size=30}{color=#009c9cff}Likes:{/color}{/size}{size=25} Sweets & fruits, detective movies, video games, \nSilk moths{/size}"
    new "{size=30}{color=#009c9cff}Le gusta:{/color}{/size}{size=25} los dulces y las frutas, las películas de detectives, los videojuegos, \nlas polillas de la seda{/size}"

    # game/glossary.rpy:865
    old "{size=30}{color=#009c9cff}Dislikes:{/color}{/size}{size=25} Spicy food, naggy people, injustice, bullies, \negotistic people{/size}"
    new "{size=30}{color=#009c9cff}No le gusta:{/color}{/size}{size=25} la comida picante, las personas molestas, la injusticia, los acosadores, \nlas personas egocéntricas{/size}"

    # game/glossary.rpy:877
    old "Some say he's a troublemaker, some say he's the best student in school, whichever it is, everyone knows that Hyugo is a very reliable person. However, due to his duties be it personal or the school asking for his services, he tends to not attend his class thus earning the title: Mister MIA (but he gets graded regardless due to his services to the school).\n{p}He is often seen hanging out at the school's rooftop, despite being warned multiple times he's forbidden from entering, he somehow still manages to enter to the point the staff just leaves him be. Hyugo is a fun and loving person, getting excited with the tiniest bit of newfound fact or trivia and because of his bubbly personality, he gets along with almost anyone. \n{p}He is Sol's one and only best friend."
    new "Algunos dicen que es un alborotador y otros que es el mejor estudiante de la escuela. Sea como sea, todos saben que Hyugo es una persona muy confiable. Sin embargo, debido a sus obligaciones, ya sean personales o relacionadas con los servicios que la escuela le solicita, suele faltar a clases, lo que le ha valido el apodo de «Mister MIA» (aunque recibe sus calificaciones de todos modos debido a los servicios que presta a la escuela).\n{p}A menudo se le ve pasando el rato en la azotea de la escuela. A pesar de que le han advertido varias veces que tiene prohibido entrar, de alguna manera sigue consiguiendo acceder hasta el punto de que el personal simplemente lo deja estar. Hyugo es una persona divertida y cariñosa que se emociona con el más mínimo dato o curiosidad nueva y, gracias a su personalidad alegre, se lleva bien con casi todo el mundo. \n{p}Es el único y mejor amigo de Sol."

    # game/glossary.rpy:923
    old "Hyugo's thoughts towards..."
    new "Los pensamientos de Hyugo sobre..."

    # game/glossary.rpy:1107
    old "Hyugo is a character that I've made back in 2021 (covid wowe), he isn't originally going to be part of this game but decided to put him in cause why the fuck not. I wanted the 'cheerful best friend' type, at first he was supposed to be the MC's best friend but I ended up giving the role to Sol since I wanted Sol to not be a lone fuck but showing how people like Sol isn't meant to be alone and deserves a best friend.\n"
    new "Hyugo es un personaje que creé en 2021 (COVID, vaya), originalmente no iba a formar parte de este juego, pero decidí incluirlo porque, ¿por qué carajos no? Quería el típico 'mejor amigo alegre'. Al principio se suponía que sería el mejor amigo del protagonista, pero terminé dándole ese papel a Sol porque no quería que Sol fuera un maldito solitario; quería mostrar que personas como Sol no están destinadas a estar solas y merecen tener un mejor amigo.\n"

    # game/glossary.rpy:1114
    old "He is inspired by characters like Hinata Shoyo from Haikyuu, super energetic and cheerful, often loud as well, but I didn't want his personality to end just like that, he is also mature and knows when to step down when he needs to. Basically, he's the anchor that keeps Sol down when it comes to making brash decisions.\n"
    new "Está inspirado en personajes como Hinata Shoyo de Haikyuu: es muy enérgico y alegre, y a menudo también bastante ruidoso, pero no quería que su personalidad se limitara a eso. También es maduro y sabe cuándo dar un paso atrás cuando es necesario. Básicamente, es el ancla que mantiene a Sol con los pies en la tierra cuando se trata de tomar decisiones impulsivas.\n"

    # game/glossary.rpy:1121
    old "Despite his cheerful character, I wouldn't get along with this person, probably because he seems to be the two-faced type and I am not fond of 'fake personalities' also adding the fact what he did with MC during their first meeting. In short, I wouldn't be seen 10 feet near this guy.\n"
    new "A pesar de su carácter alegre, no creo que me llevaría bien con él, probablemente porque parece ser de esos que tienen dos caras y no me gustan las 'personalidades falsas', además de lo que hizo con el protagonista durante su primer encuentro. En resumen, no me verían ni a tres metros de este tipo.\n"

    # game/glossary.rpy:1128
    old "He is one of my absolute favorites considering he is made right before Sol, he's got a special place in my heart. Hyugo is a mysterious person and won't be seen a lot but I hope you all would enjoy him regardless the amount of scenes he's going to show up in!\n"
    new "Es uno de mis personajes favoritos, especialmente porque lo creé justo antes que a Sol, así que ocupa un lugar especial en mi corazón. Hyugo es una persona misteriosa y no aparecerá mucho, pero espero que todos disfruten de él sin importar la cantidad de escenas en las que vaya a aparecer.\n"

    # game/glossary.rpy:1188
    old "Subaru Oogami | Geo"
    new "Subaru Oogami | Geo"

    # game/glossary.rpy:1199
    old "{size=30}{color=#017c80ff}Birthday:{/color}{/size}{size=25} January 10{/size}"
    new "{size=30}{color=#017c80ff}Cumpleaños:{/color}{/size}{size=25} 10 de enero{/size}"

    # game/glossary.rpy:1203
    old "{size=30}{color=#017c80ff}Age:{/color}{/size}{size=25} 22{/size}"
    new "{size=30}{color=#017c80ff}Edad:{/color}{/size}{size=25} 22{/size}"

    # game/glossary.rpy:1207
    old "{size=30}{color=#017c80ff}Height:{/color}{/size}{size=25} 191cm{/size}"
    new "{size=30}{color=#017c80ff}Altura:{/color}{/size}{size=25} 191 cm{/size}"

    # game/glossary.rpy:1211
    old "{size=30}{color=#017c80ff}Likes:{/color}{/size}{size=25} potted plants, opera music & theater, \nshadow puppetry, Kyudou, cats & reptiles{/size}"
    new "{size=30}{color=#017c80ff}Le gusta:{/color}{/size}{size=25} las plantas en macetas, la música de ópera y el teatro, \nel teatro de sombras, el Kyūdō, los gatos y los reptiles{/size}"

    # game/glossary.rpy:1215
    old "{size=30}{color=#017c80ff}Dislikes:{/color}{/size}{size=25} rowdy places, disobedience, bad hair day, Hyugo{/size}"
    new "{size=30}{color=#017c80ff}No le gusta:{/color}{/size}{size=25} los lugares alborotados, la desobediencia, los días en que su cabello no coopera, Hyugo{/size}"

    # game/glossary.rpy:1228
    old "Formerly ranked as a High Class, a near accident caused Subaru's (also known as Geo) status to fall and he was transferred down to the Low Class building.\n{p}He is broody and moody, mad at anything and at anyone. He came from a foreign origin with the ability to speak in 5 different languages, helping him rise up to where he is right now. Geo dreams for a life of tranquility and appreciates his alone time. He can be strict when he wants to and would not hesitate to cut anyone down be it verbally or physically. \n{p}Is Crowe's very first friend entering college."
    new "Anteriormente clasificado en la Clase Alta, un accidente que estuvo a punto de ocurrir provocó que el estatus de Subaru (también conocido como Geo) descendiera y fuera transferido al edificio de la Clase Baja.\n{p}Es malhumorado y hosco, y se enfada por cualquier cosa y con cualquiera. Proviene de un país extranjero y tiene la capacidad de hablar cinco idiomas diferentes, lo que le ayudó a llegar hasta donde está ahora. Geo sueña con una vida tranquila y aprecia pasar tiempo a solas. Puede ser estricto cuando quiere y no dudaría en acabar con cualquiera, ya sea verbal o físicamente. \n{p}Es el primer amigo que Crowe hace al entrar a la universidad."

    # game/glossary.rpy:1275
    old "Geo's thoughts towards..."
    new "Los pensamientos de Geo sobre..."

    # game/glossary.rpy:1459
    old "Just like how I made Sol and Hyugo, I wanted Crowe to have a friend, but as a group. Wanting Crowe to have a variety of friends I first sketched up Geo and labeled him as the 'delinquent'. I thought it would be funny that a delinquent would be friends with a pretty boy so I decided, what if he's a delinquent pretty boy?\n"
    new "Al igual que hice con Sol y Hyugo, quería que Crowe tuviera un amigo, pero esta vez como parte de un grupo. Quería que Crowe tuviera amigos variados, así que primero dibujé a Geo y lo etiqueté como el 'delincuente'. Pensé que sería divertido que un delincuente fuera amigo de un chico guapo, así que pensé: ¿y si fuera un chico guapo y delincuente?\n"

    # game/glossary.rpy:1466
    old "Like how Hyugo is to Sol, Geo is the complete opposite to Crowe. While Crowe is a caring and charming person, Geo is a snob and a jerk. His apperance is inspired by Masato Hijirikawa from UtaPri but during my render, I ended up giving him violet undertones (to match his jacket) and he ended up looking like Wanderer from Genshin Impact (lol) so no, his inspiration is not Scara but Masato Hijirikawa.\n"
    new "Al igual que Hyugo con Sol, Geo es completamente opuesto a Crowe. Mientras que Crowe es una persona cariñosa y encantadora, Geo es un snob y un imbécil. Su apariencia está inspirada en Masato Hijirikawa de UtaPri, pero durante el render terminé dándole matices violetas (para combinar con su chaqueta) y acabó pareciéndose a Wanderer de Genshin Impact (jaja). Así que no, su inspiración no es Scara, sino Masato Hijirikawa.\n"

    # game/glossary.rpy:1473
    old "No :)\n\nJokes aside, his personality is too strict and matches mine way too much, we'd probably be in a heated debate and it would absolutely end up with me crying my eyes off. Geo is ruthless and strict, he's terrifying and I wouln't even imagine being friends with this type of person.\n"
    new "No :)\n\nBromas aparte, su personalidad es demasiado estricta y se parece demasiado a la mía. Probablemente terminaríamos en un acalorado debate y acabaría llorando a mares. Geo es despiadado y estricto, da miedo y ni siquiera me imagino siendo amiga de alguien así.\n"

    # game/glossary.rpy:1480
    old "Shout out to the Geo simps who is to this day, coping that he is not a Love Interest, he's going to be one of those few NPCs in video games where you can't date them. Jokes aside, I hope you'll enjoy his character throughout future updates! He definitely has a huge role in the story, but that goes for everyone too!\n"
    new "Un saludo a los fans de Geo que, a día de hoy, siguen lamentándose porque no es un interés amoroso. Será uno de esos pocos NPC de videojuegos con los que no puedes tener una relación. Bromas aparte, ¡espero que disfruten de su personaje en futuras actualizaciones! Definitivamente tiene un papel muy importante en la historia, aunque eso también se aplica a todos los demás.\n"

    # game/glossary.rpy:1541
    old "Brittney Claire"
    new "Brittney Claire"

    # game/glossary.rpy:1552
    old "{size=30}{color=#ff008cff}Birthday:{/color}{/size}{size=25} July 5{/size}"
    new "{size=30}{color=#ff008cff}Cumpleaños:{/color}{/size}{size=25} 5 de julio{/size}"

    # game/glossary.rpy:1556
    old "{size=30}{color=#ff008cff}Age:{/color}{/size}{size=25} 23{/size}"
    new "{size=30}{color=#ff008cff}Edad:{/color}{/size}{size=25} 23{/size}"

    # game/glossary.rpy:1560
    old "{size=30}{color=#ff008cff}Height:{/color}{/size}{size=25} 175cm (without platforms){/size}"
    new "{size=30}{color=#ff008cff}Altura:{/color}{/size}{size=25} 175 cm (sin plataformas){/size}"

    # game/glossary.rpy:1564
    old "{size=30}{color=#ff008cff}Likes:{/color}{/size}{size=25} Fashion magazines, beauty products, \nJapanese fashion, koi fishes, cooking pastries{/size}"
    new "{size=30}{color=#ff008cff}Le gusta:{/color}{/size}{size=25} las revistas de moda, los productos de belleza, \nla moda japonesa, los peces koi, preparar repostería{/size}"

    # game/glossary.rpy:1568
    old "{size=30}{color=#ff008cff}Dislikes:{/color}{/size}{size=25} dirt and grime, roaches and insects, \nbullies, higher class{/size}"
    new "{size=30}{color=#ff008cff}No le gusta:{/color}{/size}{size=25} la suciedad y la mugre, las cucarachas y los insectos, \nlos acosadores, la clase alta{/size}"

    # game/glossary.rpy:1581
    old "Tall, blonde, and gorgeous. Brittney (Brit for short) is the group's assigned 'leader'. She is what people would call, the 'girl of their dreams'. {p}Despite of her immaculate beauty, being born in the middle class made her a target of bullying and because of this, she has a hard time expressing her feelings, thinking that she would always need her guard up no matter who it is, turning her words flat and harsh. \n{p}Despite this, she tries her best. Is the second person Crowe befriended along with Jess."
    new "Alta, rubia y hermosa. Brittney (Brit, para abreviar) es la 'líder' designada del grupo. Es lo que la gente llamaría la 'chica de sus sueños'. {p}A pesar de su belleza impecable, haber nacido en la clase media la convirtió en blanco de acoso y, debido a ello, le cuesta expresar sus sentimientos. Piensa que siempre debe estar a la defensiva, sin importar quién sea la otra persona, lo que hace que sus palabras sean frías y duras. \n{p}A pesar de todo, hace lo mejor que puede. Es la segunda persona con la que Crowe entabló amistad, junto con Jess."

    # game/glossary.rpy:1624
    old "Brit's thoughts towards..."
    new "Los pensamientos de Brit sobre..."

    # game/glossary.rpy:1813
    old "The second in the list of Crowe's group of friends. I wanted to add another type of variety within the friend group. I thought of Brittney when I thought about my friend in FFXIV, how she's fond of gyaru fashion and I noticed that there's barely any good representation of gyarus in video games and in visual novels so here I made Brittney.\n"
    new "La segunda de la lista del grupo de amigos de Crowe. Quería añadir otro tipo de variedad al grupo de amigos. Pensé en Brittney cuando recordé a mi amiga de FFXIV y su afición por la moda gyaru. También noté que apenas hay buenas representaciones de gyarus en los videojuegos y las novelas visuales, así que por eso creé a Brittney.\n"

    # game/glossary.rpy:1820
    old "Besides my friend, I am a fan of the way gyarus dress both fashion and make up wise. {p}\nBrittney is definitely a hime gyaru and I applied it to the way she speaks and carries herself. Yes she's still a bad bitch when she needs to but most of the time her default energy is neutral, serious and mature. I am a fan of pink and blue so I applied that color scheme to her design.{p}\nA little funny fact is that her top is based off of how I felt back when I was in school, I couldn't afford to make a new set of uniform and so I used my old one, but it got a bit too tight on me that the buttons were fighting for its life, so for all my big busted girlies out there, the struggle is real.\n"
    new "Además de mi amiga, me gusta la forma en que las gyarus se visten y se maquillan. {p}\nBrittney definitivamente es una hime gyaru, y apliqué ese estilo a su forma de hablar y comportarse. Sí, sigue siendo una chica de carácter fuerte cuando hace falta, pero la mayor parte del tiempo su actitud habitual es neutral, seria y madura. Me gustan el rosa y el azul, así que apliqué esa combinación de colores a su diseño.{p}\nUn dato curioso es que su blusa está basada en cómo me sentía cuando estaba en la escuela. No podía permitirme un uniforme nuevo, así que usaba el antiguo, pero me quedó un poco demasiado ajustado y los botones parecían estar luchando por su vida. Así que, para todas mis chicas de busto grande, la lucha es real.\n"

    # game/glossary.rpy:1827
    old "I would probably be scared of her at first but the second you get to know her, she's actually a very fun and kind person, she just has a 'resting bitch face' as some would say. She is fond of making sandwiches and would try to come up with ideas for a group outing.\n"
    new "Probablemente me daría miedo al principio, pero en cuanto la conociera, descubriría que en realidad es una persona muy divertida y amable. Simplemente tiene lo que algunos llamarían una 'cara de pocos amigos'. Le gusta preparar sándwiches y trataría de proponer ideas para una salida en grupo.\n"

    # game/glossary.rpy:1834
    old "I hope you all will love Brittney as much as I did writing her! Her development was kind of late but that goes to the rest of the friend group since I made them on the whim but there will be more to Brittney and her background as I update more!\n"
    new "¡Espero que todos quieran a Brittney tanto como yo disfruté escribiéndola! Su desarrollo llegó un poco tarde, pero lo mismo ocurrió con el resto del grupo de amigos, ya que los creé sobre la marcha. ¡Habrá más sobre Brittney y su historia a medida que publique nuevas actualizaciones!\n"

    # game/glossary.rpy:1896
    old "Deryl Helianthus"
    new "Deryl Helianthus"

    # game/glossary.rpy:1907
    old "{size=30}{color=#827e00}Birthday:{/color}{/size}{size=25} June 30{/size}"
    new "{size=30}{color=#827e00}Cumpleaños:{/color}{/size}{size=25} 30 de junio{/size}"

    # game/glossary.rpy:1911
    old "{size=30}{color=#827e00}Age:{/color}{/size}{size=25} 23{/size}"
    new "{size=30}{color=#827e00}Edad:{/color}{/size}{size=25} 23{/size}"

    # game/glossary.rpy:1915
    old "{size=30}{color=#827e00}Height:{/color}{/size}{size=25} 195cm{/size}"
    new "{size=30}{color=#827e00}Altura:{/color}{/size}{size=25} 195 cm{/size}"

    # game/glossary.rpy:1919
    old "{size=30}{color=#827e00}Likes:{/color}{/size}{size=25} sports(football being his favorite), sweets, \nany type of fast food, dogs{/size}"
    new "{size=30}{color=#827e00}Le gusta:{/color}{/size}{size=25} los deportes (el fútbol es su favorito), los dulces, \ncualquier tipo de comida rápida, los perros{/size}"

    # game/glossary.rpy:1923
    old "{size=30}{color=#827e00}Dislikes:{/color}{/size}{size=25} his coach, selfish people, monday mornings{/size}"
    new "{size=30}{color=#827e00}No le gusta:{/color}{/size}{size=25} su entrenador, las personas egoístas, los lunes por la mañana{/size}"

    # game/glossary.rpy:1935
    old "One of Olympeius's top ace players in the football team. Deryl is a tall and hyperactive giant, with his impending height, people often get weary whenever he comes around especially if he's in a hyper mood. \n{p}Despite being an absolute disaster magnet, Deryl is a sweet and kind person, with a fondess for animals, especially dogs. Be careful with giving him sweets! He will go on a hyperactive marathon. \n{p}The last person entering Crowe's friend group."
    new "Uno de los mejores jugadores del equipo de fútbol de Olympeius. Deryl es un gigante alto e hiperactivo. Debido a su imponente estatura, la gente suele ponerse nerviosa cuando aparece, especialmente cuando está de humor hiperactivo. \n{p}A pesar de ser un imán absoluto para los desastres, Deryl es una persona dulce y amable a la que le encantan los animales, especialmente los perros. ¡Ten cuidado al darle dulces! Se embarcará en un maratón de hiperactividad. \n{p}Es la última persona en unirse al grupo de amigos de Crowe."

    # game/glossary.rpy:1977
    old "Deryl's thoughts towards..."
    new "Los pensamientos de Deryl sobre..."

    # game/glossary.rpy:2165
    old "The third in the list of Crowe's group of friends. This time, I made a jock, very typical right? But I made the world's setting to match from early to mid 2000s and jocks were pretty popular back then. But other than a jock, he is a himbo and a golden retriever.\n"
    new "El tercero de la lista del grupo de amigos de Crowe. Esta vez creé a un deportista, muy típico, ¿verdad? Pero hice que la ambientación del mundo correspondiera a principios y mediados de los años 2000, y los deportistas eran bastante populares por aquel entonces. Pero, además de ser deportista, es un himbo y un golden retriever.\n"

    # game/glossary.rpy:2172
    old "His design is inspired by Alex from Stardew Valley, you can probably say he is Alex and Geo is Sebastian. I wanted a youthful and naive student and I thought of one of my few friends who shares almost the same personality as Deryl. Showing how someone as old as 22-23 can still feel and act like they're young like they're back in their highschool years and there's nothing wrong with that! Plus Deryl can be mature when he wants to and knows when to step his foot down.\n"
    new "Su diseño está inspirado en Alex de Stardew Valley; se podría decir que él es Alex y Geo es Sebastian. Quería un estudiante joven e ingenuo y pensé en uno de mis pocos amigos, que comparte casi la misma personalidad que Deryl. Quería mostrar cómo alguien de 22-23 años todavía puede sentirse y actuar como cuando era joven, como si estuviera de nuevo en sus años de secundaria, ¡y no hay nada de malo en ello! Además, Deryl puede ser maduro cuando quiere y sabe cuándo debe ponerse firme.\n"

    # game/glossary.rpy:2179
    old "He would absolutely pick me up by the shoulders and spin me around until I throw up on his jersey. If you want someone to cheer you up, Deryl's the guy for you, making you wash away your worries even just for a short moment. He is a cheerful and caring person and he will do his best to lift your spirits.\n"
    new "Definitivamente me levantaría por los hombros y me haría girar hasta que terminara vomitando sobre su camiseta. Si quieres a alguien que te anime, Deryl es el indicado para ti. Hará que te olvides de tus preocupaciones, aunque solo sea por un momento. Es una persona alegre y cariñosa, y hará todo lo posible por levantarte el ánimo.\n"

    # game/glossary.rpy:2186
    old "Thank you so much for loving Deryl! I know there's not much about him for now but his role is just as important as the rest of the cast! I hope you all will look forward to his character development in future updates!\n"
    new "¡Muchas gracias por querer a Deryl! Sé que por ahora no hay mucho sobre él, pero su papel es tan importante como el del resto del elenco. ¡Espero que todos esperen con ilusión el desarrollo de su personaje en futuras actualizaciones!\n"

    # game/glossary.rpy:2249
    old "Jessie Sitrus"
    new "Jessie Sitrus"

    # game/glossary.rpy:2260
    old "{size=30}{color=#d74b00}Birthday:{/color}{/size}{size=25} April 26{/size}"
    new "{size=30}{color=#d74b00}Cumpleaños:{/color}{/size}{size=25} 26 de abril{/size}"

    # game/glossary.rpy:2264
    old "{size=30}{color=#d74b00}Age:{/color}{/size}{size=25} 22{/size}"
    new "{size=30}{color=#d74b00}Edad:{/color}{/size}{size=25} 22{/size}"

    # game/glossary.rpy:2268
    old "{size=30}{color=#d74b00}Height:{/color}{/size}{size=25} 150cm{/size}"
    new "{size=30}{color=#d74b00}Altura:{/color}{/size}{size=25} 150 cm{/size}"

    # game/glossary.rpy:2272
    old "{size=30}{color=#d74b00}Likes:{/color}{/size}{size=25} Seafood, books, video games, Eries her #1 Idol{/size}"
    new "{size=30}{color=#d74b00}Le gusta:{/color}{/size}{size=25} los mariscos, los libros, los videojuegos, Eries, su ídolo n.º 1{/size}"

    # game/glossary.rpy:2276
    old "{size=30}{color=#d74b00}Dislikes:{/color}{/size}{size=25} deers, haunted houses, bullies{/size}"
    new "{size=30}{color=#d74b00}No le gusta:{/color}{/size}{size=25} los ciervos, las casas embrujadas, los acosadores{/size}"

    # game/glossary.rpy:2288
    old "Jessie or (Jess for short) is a timid girl who people tend to forget. She isn't well known in school and she would like to keep it that way, refusing to grab any sort of attention. \n{p}However, she is a whole different person online, having to run one of Titus' Top Idols: 'ERIES' fan pages, she is well respected by the people within her community. She is a creative person and a major geek, often cosplaying in conventions. \n{p}Because of her 'weird' nature and introvert personality, she is often forgotten by people in school. \n{p}Is the second person to befriend Crowe with Brittney."
    new "Jessie, o Jess para abreviar, es una chica tímida que la gente tiende a olvidar. No es muy conocida en la escuela y le gustaría que siguiera siendo así, por lo que evita llamar cualquier tipo de atención. \n{p}Sin embargo, en internet es una persona completamente diferente. Administra una de las páginas de fans de 'ERIES', una de las principales idols de Titus, y es muy respetada por las personas de su comunidad. Es una persona creativa y una gran geek, y suele hacer cosplay en convenciones. \n{p}Debido a su naturaleza 'extraña' y su personalidad introvertida, la gente de la escuela suele olvidarse de ella. \n{p}Es la segunda persona, junto con Brittney, que se hace amiga de Crowe."

    # game/glossary.rpy:2335
    old "Jess' thoughts towards..."
    new "Los pensamientos de Jess sobre..."

    # game/glossary.rpy:2520
    old "The last in the list of Crowe's group of friends. Last but not the least, the single petite and quiet introvert, Crowe's the type to befriend anyone and that includes introverts. But other than that, she's a huge geek, she's basically the little geek in a friend group who would suggest watching movies together or drag someone to watch a show and would talk non-stop about it.\n"
    new "La última de la lista del grupo de amigos de Crowe. Por último, pero no menos importante, está la única chica menuda y tranquila del grupo, una introvertida. Crowe es de los que se hacen amigos de cualquiera, y eso incluye a los introvertidos. Pero, además, ella es una gran geek; básicamente, es la pequeña geek del grupo de amigos que propondría ver películas juntos o arrastraría a alguien a ver una serie para luego hablar de ella sin parar.\n"

    # game/glossary.rpy:2527
    old "Her design is inspired by me back when I was in highschool personality wise. Kept in the dark and oftentimes known as the 'anime girl'. Unlike me though, Jess isn't that good at drawing but in writing. Jess represents my shy nature, high trust issues and the fear of being misjudged, often sticking to one person in a group and in her case, it's with Brittney.\n"
    new "Su diseño está inspirado en cómo era yo cuando estaba en secundaria, especialmente en cuanto a personalidad. Siempre en segundo plano y a menudo conocida como 'la chica del anime'. A diferencia de mí, Jess no es tan buena dibujando, pero sí escribiendo. Jess representa mi naturaleza tímida, mis grandes problemas de confianza y el miedo a ser juzgada injustamente. Suele aferrarse a una sola persona dentro de un grupo y, en su caso, esa persona es Brittney.\n"

    # game/glossary.rpy:2534
    old "I would come to her first and befriend her, geek to geek contact, we would hit it off pretty easily, one mention of a brainrot and you'll have a whole conversation running. Jess is a fun and cheerful person once she breaks away from her shell and knows that she won't be judged and mistreated.\n"
    new "Yo me acercaría primero a ella y me haría su amiga. Sería un encuentro de geek a geek y nos llevaríamos bastante bien. Bastaría con mencionar algún brainrot para que empezáramos una conversación interminable. Jess es una persona divertida y alegre una vez que sale de su caparazón y sabe que no la juzgarán ni la tratarán mal.\n"

    # game/glossary.rpy:2541
    old "To people who relate to Jess, I feel you all (lol) but thank you so much for loving Jess! She doesn't have much to offer as of the moment just like Deryl and Brittney but her role as a part of the game is very relevant to each character's development and I hope you all get to enjoy her now and in future updates!\n"
    new "A quienes se sienten identificados con Jess, los entiendo (jaja), pero ¡muchísimas gracias por querer a Jess! Por ahora no tiene tanto que ofrecer, al igual que Deryl y Brittney, pero su papel en el juego es muy relevante para el desarrollo de cada personaje. ¡Espero que puedan disfrutar de ella tanto ahora como en futuras actualizaciones!\n"
