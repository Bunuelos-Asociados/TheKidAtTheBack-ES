﻿# TODO: Translation updated at 2026-09-25 20:21

translate spanish strings:

    # game/options.rpy:17
    old "The Kid at the Back-NSFW v2.3.3"
    new "The Kid at the Back-NSFW v2.3.3"

