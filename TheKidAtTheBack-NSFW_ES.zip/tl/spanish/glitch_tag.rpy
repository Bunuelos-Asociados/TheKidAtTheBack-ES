# TODO: Translation updated at 2026-09-25 20:21

# game/glitch_tag.rpy:1
translate spanish 6c0c3176:

    # "Kinetic Text Tags Ren'Py Module 2021 Daniel Westfall <SoDaRa2595@gmail.com>"
    "Kinetic Text Tags Ren'Py Module 2021 Daniel Westfall <SoDaRa2595@gmail.com>"

# game/glitch_tag.rpy:2
translate spanish bcfb2ad4:

    # "http://twitter.com/sodara9 I'd appreciate being given credit if you do end up using it! :D Would really make my day to know I helped some people out! Really hope this can help the community create some really neat ways to spice up their dialogue! http://opensource.org/licenses/mit-license.php Forum Post: https://lemmasoft.renai.us/forums/viewtopic.php?f=51&t=60527&sid=75b4eb1aa5212a33cbfe9b0354e5376b Github: https://github.com/SoDaRa/Kinetic-Text-Tags itch.io: https://wattson.itch.io/kinetic-text-tags"
    "http://twitter.com/sodara9 Agradecería que se me diera crédito si lo usas! :D ¡Realmente alegraría mi día saber que ayudé a algunas personas! ¡Espero que esto pueda ayudar a la comunidad a crear formas realmente geniales de darle vida a sus diálogos! http://opensource.org/licenses/mit-license.php Forum Post: https://lemmasoft.renai.us/forums/viewtopic.php?f=51&t=60527&sid=75b4eb1aa5212a33cbfe9b0354e5376b Github: https://github.com/SoDaRa/Kinetic-Text-Tags itch.io: https://wattson.itch.io/kinetic-text-tags"

